const LOCAL_STATE_KEY = "japaneseImmersionTrackerState";
const DEVICE_ID_KEY = "japaneseImmersionTrackerDeviceId";
const SYNC_RECORD_PREFIX = "jitRecordV2:";
const SYNC_DECISION_PREFIX = "jitDecisionV2:";
const SYNC_RESET_KEY = "jitResetV2";
const SYNC_GOALS_KEY = "jitGoalsV1";
const SYNC_ALARM = "jitSyncV2";
const MANUAL_ALARM = "jitManualTimerV1";
const HOTKEY_GUIDE_REQUEST_KEY = "jitShowHotkeysRequestedAt";
const DECISION_BUCKETS = 16;
const MAX_CONTENT_DECISIONS_PER_BUCKET = 30;
const MAX_SOURCE_DECISIONS_PER_BUCKET = 30;
const SYNC_MONTH_RETENTION = 12;
const DEFAULT_TARGET_LANGUAGE = { code: "ja", name: "Japanese" };
const WEEKLY_REVIEW_ALARM = "litWeeklyReviewV1";
const LANGUAGE_NAMES = {
  ja: "Japanese", en: "English", sv: "Swedish", es: "Spanish", fr: "French",
  de: "German", it: "Italian", pt: "Portuguese", ko: "Korean", zh: "Chinese",
  ru: "Russian", uk: "Ukrainian", ar: "Arabic", hi: "Hindi", tr: "Turkish",
  pl: "Polish", nl: "Dutch", da: "Danish", no: "Norwegian", fi: "Finnish",
  vi: "Vietnamese", th: "Thai", id: "Indonesian", ms: "Malay",
  tl: "Filipino / Tagalog", el: "Greek", he: "Hebrew", fa: "Persian / Farsi",
  bn: "Bengali", ur: "Urdu", cs: "Czech", ro: "Romanian", hu: "Hungarian",
  bg: "Bulgarian", hr: "Croatian", sr: "Serbian", sk: "Slovak", sl: "Slovenian",
  et: "Estonian", lv: "Latvian", lt: "Lithuanian", is: "Icelandic",
  sw: "Swahili", ca: "Catalan", eu: "Basque", gl: "Galician", cy: "Welsh", ga: "Irish"
};

function normalizeLanguageCode(value) {
  const code = String(value || "").trim().toLowerCase().replace(/_/g, "-");
  return /^[a-z]{2,3}(?:-[a-z0-9]{2,8})*$/.test(code) ? code.slice(0, 24) : "ja";
}

function normalizeTargetLanguage(value) {
  const input = typeof value === "string" ? { code: value } : (value || {});
  const code = normalizeLanguageCode(input.code || DEFAULT_TARGET_LANGUAGE.code);
  const canonicalName = LANGUAGE_NAMES[code] || LANGUAGE_NAMES[code.split("-")[0]];
  const name = String(canonicalName || input.name || code.toUpperCase())
    .trim()
    .replace(/\s+/g, " ")
    .slice(0, 50);
  return { code, name: name || code.toUpperCase() };
}

function decisionStorageKey(languageCode, key) {
  return normalizeLanguageCode(languageCode) + "|" + key;
}

function normalizeDecision(value) {
  if (value === "target" || value === "japanese") return "target";
  if (value === "not-target" || value === "not-japanese") return "not-target";
  return null;
}

const emptyState = () => ({
  version: 6,
  records: {},
  languageRecords: {},
  sessions: {},
  lastDeletedSession: null,
  notificationState: {},
  manualTimer: null,
  preferences: {
    autoMinimizeEnabled: true,
    autoMinimizeSeconds: 5,
    overlayPosition: null,
    componentOrder: ["session", "calendar-goals", "insights", "manual", "completed", "history"],
    collapsedComponents: {
      session: false,
      "calendar-goals": false,
      insights: true,
      manual: true,
      completed: true,
      history: true
    },
    uiLayoutVersion: 2,
    historyLimit: 5,
    notificationsEnabled: true,
    theme: "dark",
    onboardingCompleted: false,
    lastManualSource: "reading",
    lastManualAction: "",
    lastManualMode: "active",
    customManualCategories: [],
    targetLanguage: { ...DEFAULT_TARGET_LANGUAGE },
    languageNames: { ja: "Japanese" },
    goals: {
      daily: { enabled: true, minutes: 360 },
      weekly: { enabled: true, minutes: 900 },
      monthly: { enabled: false, minutes: 3600 },
      yearly: { enabled: false, minutes: 42000 }
    }
  },
  decisions: {
    content: {},
    source: {}
  },
  sourceLearning: {},
  sync: {
    dirtyMonths: {},
    lastSyncedAt: 0,
    lastResetSeen: 0
  }
});

let stateQueue = Promise.resolve();
let syncQueue = Promise.resolve();
let dashboardCache = { at: 0, languageCode: "", records: null };
const liveStatus = {};
let automaticOwnerTabId = null;

function chooseAutomaticOwnerTabId() {
  const candidates = Object.entries(liveStatus)
    .filter(([, status]) =>
      status?.languageState === "confirmed" &&
      status?.countingEligible &&
      status?.playing &&
      !status?.trackingPaused &&
      !status?.tabMuted
    )
    .sort((a, b) => {
      if (Boolean(a[1].activeImmersion) !== Boolean(b[1].activeImmersion)) {
        return a[1].activeImmersion ? -1 : 1;
      }
      return (Number(b[1].updatedAt) || 0) - (Number(a[1].updatedAt) || 0);
    });
  const current = candidates.find(([id]) => Number(id) === automaticOwnerTabId);
  if (current?.[1]?.activeImmersion) return automaticOwnerTabId;
  return candidates.length ? Number(candidates[0][0]) : null;
}

function localDateKey(timestamp = Date.now()) {
  const date = new Date(timestamp);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function parseLocalDateKey(value) {
  const dateKey = String(value || "").trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateKey)) return "";
  const timestamp = new Date(dateKey + "T12:00:00").getTime();
  return Number.isFinite(timestamp) && localDateKey(timestamp) === dateKey ? dateKey : "";
}

function monthKeyFromDateKey(dateKey) {
  return String(dateKey || "").slice(0, 7);
}

function normalizeState(stored) {
  if (!stored || typeof stored !== "object") return emptyState();
  const defaults = emptyState();
  const storedGoals = stored.preferences?.goals || {};
  const legacyRecords = stored.records || {};
  const languageRecords = stored.languageRecords && typeof stored.languageRecords === "object"
    ? stored.languageRecords
    : Object.keys(legacyRecords).length
      ? { ja: legacyRecords }
      : {};
  const validComponentIds = ["session", "calendar-goals", "insights", "manual", "completed", "history"];
  const oldIdMap = { "session-goals": "session", calendar: "calendar-goals" };
  const migratedOrder = (stored.preferences?.componentOrder || [])
    .map((id) => oldIdMap[id] || id)
    .filter((id, index, items) => validComponentIds.includes(id) && items.indexOf(id) === index);
  const hasCurrentLayout = Number(stored.preferences?.uiLayoutVersion) >= 2;
  const onboardingCompleted = stored.preferences?.onboardingCompleted == null
    ? true
    : stored.preferences.onboardingCompleted === true;
  return {
    ...defaults,
    version: 6,
    records: {},
    languageRecords,
    sessions: stored.sessions || {},
    lastDeletedSession: stored.lastDeletedSession || null,
    notificationState: stored.notificationState || {},
    manualTimer: stored.manualTimer ? { ...stored.manualTimer, action: normalizeManualAction(stored.manualTimer.action), languageCode: normalizeLanguageCode(stored.manualTimer.languageCode || "ja") } : null,
    preferences: {
      ...defaults.preferences,
      ...(stored.preferences || {}),
      targetLanguage: normalizeTargetLanguage(stored.preferences?.targetLanguage),
      componentOrder: [
        ...(migratedOrder.length ? migratedOrder : defaults.preferences.componentOrder),
        ...validComponentIds.filter((id) => !migratedOrder.includes(id))
      ].filter((id, index, items) => items.indexOf(id) === index),
      collapsedComponents: hasCurrentLayout &&
        stored.preferences?.collapsedComponents &&
        typeof stored.preferences.collapsedComponents === "object"
          ? Object.fromEntries(validComponentIds.map((id) => [id, stored.preferences.collapsedComponents[id] === true]))
          : { ...defaults.preferences.collapsedComponents },
      uiLayoutVersion: 2,
      historyLimit: Number(stored.preferences?.historyLimit) === 10 ? 10 : 5,
      notificationsEnabled: stored.preferences?.notificationsEnabled !== false,
      theme: stored.preferences?.theme === "light" ? "light" : "dark",
      overlayPosition: stored.preferences?.overlayPosition?.custom === true &&
        Number.isFinite(Number(stored.preferences.overlayPosition.left)) &&
        Number.isFinite(Number(stored.preferences.overlayPosition.top))
          ? {
              custom: true,
              left: Math.max(0, Number(stored.preferences.overlayPosition.left)),
              top: Math.max(0, Number(stored.preferences.overlayPosition.top)),
              viewportWidth: Math.max(0, Number(stored.preferences.overlayPosition.viewportWidth) || 0),
              viewportHeight: Math.max(0, Number(stored.preferences.overlayPosition.viewportHeight) || 0)
            }
          : null,
      onboardingCompleted,
      lastManualAction: normalizeManualAction(stored.preferences?.lastManualAction),
      customManualCategories: normalizeCustomCategories(stored.preferences?.customManualCategories),
      languageNames: {
        ja: "Japanese",
        ...(stored.preferences?.languageNames || {}),
        [normalizeTargetLanguage(stored.preferences?.targetLanguage).code]:
          normalizeTargetLanguage(stored.preferences?.targetLanguage).name
      },
      goals: Object.fromEntries(
        Object.entries(defaults.preferences.goals).map(([period, goal]) => [
          period,
          { ...goal, ...(storedGoals[period] || {}) }
        ])
      )
    },
    decisions: {
      content: stored.decisions?.content || {},
      source: stored.decisions?.source || {}
    },
    sourceLearning: stored.sourceLearning || {},
    sync: {
      ...emptyState().sync,
      ...(stored.sync || {})
    }
  };
}

async function readState() {
  const result = await chrome.storage.local.get(LOCAL_STATE_KEY);
  return normalizeState(result[LOCAL_STATE_KEY]);
}

async function writeState(state) {
  await chrome.storage.local.set({ [LOCAL_STATE_KEY]: state });
}

function updateState(mutator) {
  stateQueue = stateQueue.then(async () => {
    const state = await readState();
    const result = await mutator(state);
    await writeState(state);
    dashboardCache = { at: 0, languageCode: "", records: null };
    return result;
  });
  return stateQueue;
}

async function getDeviceId() {
  const result = await chrome.storage.local.get(DEVICE_ID_KEY);
  if (result[DEVICE_ID_KEY]) return result[DEVICE_ID_KEY];
  const id = typeof crypto.randomUUID === "function"
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  await chrome.storage.local.set({ [DEVICE_ID_KEY]: id });
  return id;
}

function recordsForLanguage(state, languageCode) {
  const code = normalizeLanguageCode(languageCode || state.preferences?.targetLanguage?.code);
  state.languageRecords ||= {};
  state.languageRecords[code] ||= {};
  return state.languageRecords[code];
}

function ensureRecord(state, dateKey, site, languageCode) {
  const records = recordsForLanguage(state, languageCode);
  records[dateKey] ||= { active: 0, passive: 0, sites: {} };
  records[dateKey].sites ||= {};
  records[dateKey].sites[site] ||= { active: 0, passive: 0 };
  return records[dateKey];
}

function markMonthDirty(state, dateKey) {
  const month = monthKeyFromDateKey(dateKey);
  if (month) state.sync.dirtyMonths[month] = Date.now();
}

function clampSeconds(value) {
  const seconds = Number(value);
  if (!Number.isFinite(seconds) || seconds <= 0) return 0;
  return Math.min(seconds, 180);
}

function clampManualSeconds(value) {
  const seconds = Number(value);
  if (!Number.isFinite(seconds) || seconds <= 0) return 0;
  return Math.min(seconds, 7 * 24 * 60 * 60);
}

function normalizeManualSource(value) {
  const source = String(value || "").trim().replace(/\s+/g, " ").slice(0, 40);
  return source || "other";
}

function normalizeManualAction(value) {
  return String(value || "").trim().replace(/\s+/g, " ").slice(0, 160);
}

function normalizeCustomCategories(value) {
  if (!Array.isArray(value)) return [];
  return value
    .map(normalizeManualSource)
    .filter((item) => item !== "other")
    .filter((item, index, items) => items.findIndex((candidate) => candidate.toLowerCase() === item.toLowerCase()) === index)
    .slice(0, 30);
}

function normalizeManualMode(value) {
  return value === "passive" ? "passive" : "active";
}

function addManualSeconds(state, { source, mode, seconds, timestamp = Date.now(), languageCode }) {
  const safeSeconds = clampManualSeconds(seconds);
  if (!safeSeconds) return 0;
  const safeSource = normalizeManualSource(source);
  const safeMode = normalizeManualMode(mode);
  const dateKey = localDateKey(timestamp);
  const record = ensureRecord(state, dateKey, safeSource, languageCode);
  record[safeMode] += safeSeconds;
  record.sites[safeSource][safeMode] += safeSeconds;
  markMonthDirty(state, dateKey);
  return safeSeconds;
}

function addSessionDelta(state, sessionId, details) {
  if (!sessionId) return;
  const dateKey = details.dateKey || localDateKey(details.timestamp || Date.now());
  const active = Math.max(0, Number(details.active) || 0);
  const passive = Math.max(0, Number(details.passive) || 0);
  state.sessions[sessionId] ||= {
    kind: details.kind || "video",
    site: normalizeManualSource(details.site || "other"),
    languageCode: normalizeLanguageCode(details.languageCode),
    contentKey: details.contentKey || "",
    title: details.title || "Immersion session",
    startedAt: details.startedAt || details.timestamp || Date.now(),
    lastAt: Date.now(),
    byDate: {}
  };
  const session = state.sessions[sessionId];
  session.kind ||= details.kind || "video";
  session.languageCode = normalizeLanguageCode(session.languageCode || details.languageCode);
  session.site = normalizeManualSource(details.site || session.site);
  session.title = String(details.title || session.title || "Immersion session").slice(0, 160);
  session.lastAt = Date.now();
  session.byDate[dateKey] ||= { active: 0, passive: 0 };
  session.byDate[dateKey].active += active;
  session.byDate[dateKey].passive += passive;
}

function applySessionContribution(state, session, multiplier) {
  for (const [dateKey, contribution] of Object.entries(session?.byDate || {})) {
    const code = normalizeLanguageCode(session.languageCode || "ja");
    const site = normalizeManualSource(session.site);
    const record = multiplier > 0
      ? ensureRecord(state, dateKey, site, code)
      : state.languageRecords?.[code]?.[dateKey];
    if (!record) continue;
    const active = (Number(contribution.active) || 0) * multiplier;
    const passive = (Number(contribution.passive) || 0) * multiplier;
    record.active = Math.max(0, (Number(record.active) || 0) + active);
    record.passive = Math.max(0, (Number(record.passive) || 0) + passive);
    if (record.sites?.[site]) {
      record.sites[site].active = Math.max(0, (Number(record.sites[site].active) || 0) + active);
      record.sites[site].passive = Math.max(0, (Number(record.sites[site].passive) || 0) + passive);
      if (!record.sites[site].active && !record.sites[site].passive) delete record.sites[site];
    }
    markMonthDirty(state, dateKey);
  }
}

function periodDateKeys(period, now = new Date()) {
  if (period === "daily") return [localDateKey(now)];
  const keys = [];
  const start = new Date(now);
  start.setHours(0, 0, 0, 0);
  if (period === "weekly") {
    start.setDate(start.getDate() - (start.getDay() === 0 ? 6 : start.getDay() - 1));
    for (let i = 0; i < 7; i += 1) {
      const day = new Date(start);
      day.setDate(start.getDate() + i);
      keys.push(localDateKey(day));
    }
  } else {
    const prefix = period === "monthly"
      ? localDateKey(now).slice(0, 7) + "-"
      : String(now.getFullYear()) + "-";
    keys.push(prefix);
  }
  return keys;
}

function totalForPeriod(records, period) {
  const keys = periodDateKeys(period);
  const prefixMode = period === "monthly" || period === "yearly";
  return Object.entries(records || {}).reduce((total, [dateKey, record]) => {
    const included = prefixMode ? dateKey.startsWith(keys[0]) : keys.includes(dateKey);
    return included ? total + (Number(record.active) || 0) + (Number(record.passive) || 0) : total;
  }, 0);
}

async function notifyGoalCompletions(languageCode) {
  const notifications = [];
  await updateState((state) => {
    if (state.preferences.notificationsEnabled === false) return;
    const code = normalizeLanguageCode(languageCode || state.preferences.targetLanguage.code);
    const languageName = state.preferences.languageNames?.[code] || LANGUAGE_NAMES[code] || code.toUpperCase();
    const records = state.languageRecords?.[code] || {};
    for (const period of ["daily", "weekly", "monthly", "yearly"]) {
      const goal = state.preferences.goals?.[period];
      if (!goal?.enabled) continue;
      const stamp = period === "daily" ? localDateKey() :
        period === "weekly" ? periodDateKeys("weekly")[0] :
        period === "monthly" ? localDateKey().slice(0, 7) : String(new Date().getFullYear());
      const notificationKey = code + "|" + period + "|" + stamp;
      if (totalForPeriod(records, period) >= Number(goal.minutes) * 60 && !state.notificationState[notificationKey]) {
        state.notificationState[notificationKey] = Date.now();
        notifications.push({ period, languageName, minutes: goal.minutes });
      }
    }
  });
  for (const item of notifications) {
    try {
      await chrome.notifications.create({
        type: "basic",
        iconUrl: "icons/icon128.png",
        title: item.period[0].toUpperCase() + item.period.slice(1) + " goal complete",
        message: item.languageName + ": " + item.minutes + " minutes reached."
      });
    } catch {
      // Notifications can be unavailable in managed browser profiles.
    }
  }
}

function nextWeeklyReviewAt() {
  const now = new Date();
  const next = new Date(now);
  const days = (7 - now.getDay()) % 7;
  next.setDate(now.getDate() + days);
  next.setHours(20, 0, 0, 0);
  if (next <= now) next.setDate(next.getDate() + 7);
  return next.getTime();
}

async function showWeeklyReview() {
  const state = await readState();
  if (state.preferences.notificationsEnabled === false) return;
  const code = state.preferences.targetLanguage.code;
  const name = state.preferences.targetLanguage.name;
  const seconds = totalForPeriod(state.languageRecords?.[code] || {}, "weekly");
  const goal = Number(state.preferences.goals?.weekly?.minutes) || 900;
  try {
    await chrome.notifications.create({
      type: "basic",
      iconUrl: "icons/icon128.png",
      title: name + " weekly review",
      message: Math.round(seconds / 60) + " / " + goal + " minutes this week."
    });
  } catch {
    // Notifications can be unavailable in managed browser profiles.
  }
}

function manualTimerSnapshot(timer, now = Date.now()) {
  if (!timer) return null;
  const uncommittedSeconds = timer.running
    ? Math.max(0, (now - (Number(timer.lastCheckpointAt) || now)) / 1000)
    : 0;
  return {
    ...timer,
    committedSeconds: Number(timer.committedSeconds) || 0,
    uncommittedSeconds,
    elapsedSeconds: (Number(timer.committedSeconds) || 0) + uncommittedSeconds
  };
}

function checkpointManualTimer({ stop = false } = {}) {
  const now = Date.now();
  return updateState((state) => {
    const timer = state.manualTimer;
    if (!timer?.running) return { ok: true, timer: manualTimerSnapshot(timer, now) };
    const delta = Math.max(0, (now - (Number(timer.lastCheckpointAt) || now)) / 1000);
    const added = addManualSeconds(state, {
      source: timer.source,
      mode: timer.mode,
      seconds: delta,
      timestamp: now,
      languageCode: timer.languageCode
    });
    timer.committedSeconds = (Number(timer.committedSeconds) || 0) + added;
    addSessionDelta(state, timer.id, {
      kind: "manual",
      site: timer.source,
      title: normalizeManualAction(timer.action) || timer.source + " manual immersion",
      languageCode: timer.languageCode,
      dateKey: localDateKey(now),
      active: timer.mode === "active" ? added : 0,
      passive: timer.mode === "passive" ? added : 0,
      startedAt: timer.startedAt
    });
    timer.lastCheckpointAt = now;
    if (stop) {
      timer.running = false;
      timer.stoppedAt = now;
    }
    return { ok: true, timer: manualTimerSnapshot(timer, now) };
  });
}

async function broadcastOverlayPreferences(preferences) {
  try {
    const tabs = await chrome.tabs.query({
      url: [
        "https://www.youtube.com/*",
        "https://youtube.com/*",
        "https://www.netflix.com/*",
        "https://www.disneyplus.com/*",
        "https://www.primevideo.com/*",
        "https://www.amazon.com/gp/video/*",
        "https://www.amazon.co.uk/gp/video/*",
        "https://www.amazon.ca/gp/video/*",
        "https://www.amazon.de/gp/video/*",
        "https://www.amazon.co.jp/gp/video/*",
        "https://www.amazon.fr/gp/video/*",
        "https://www.amazon.it/gp/video/*",
        "https://www.amazon.es/gp/video/*",
        "https://www.hulu.com/*",
        "https://play.max.com/*",
        "https://tv.apple.com/*",
        "https://www.paramountplus.com/*",
        "https://www.peacocktv.com/*",
        "https://www.crunchyroll.com/*",
        "https://www.hidive.com/*",
        "https://tubitv.com/*"
      ]
    });
    await Promise.all(tabs.map((tab) => chrome.tabs.sendMessage(tab.id, {
      type: "overlayPreferencesChanged",
      preferences
    }).catch(() => null)));
  } catch {
    // Supported tabs will fetch the preferences on their next reload.
  }
}

function hashBucket(value) {
  let hash = 2166136261;
  for (const char of String(value || "")) {
    hash ^= char.charCodeAt(0);
    hash = Math.imul(hash, 16777619);
  }
  return Math.abs(hash >>> 0) % DECISION_BUCKETS;
}

function decisionSyncKey(scope, key) {
  return `${SYNC_DECISION_PREFIX}${scope}:${hashBucket(key)}`;
}

function recordSyncKey(deviceId, month) {
  return `${SYNC_RECORD_PREFIX}${deviceId}:${month}`;
}


function recentMonthKeys(count = SYNC_MONTH_RETENTION) {
  const now = new Date();
  return Array.from({ length: count }, (_, index) => {
    const date = new Date(now.getFullYear(), now.getMonth() - index, 1);
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
  });
}

function extractMonthRecords(records, month) {
  return Object.fromEntries(
    Object.entries(records || {}).filter(([dateKey]) => dateKey.startsWith(month + "-"))
  );
}

function extractMonthLanguageRecords(languageRecords, month) {
  return Object.fromEntries(
    Object.entries(languageRecords || {})
      .map(([languageCode, records]) => [languageCode, extractMonthRecords(records, month)])
      .filter(([, records]) => Object.keys(records).length)
  );
}

function pruneDecisionEntries(entries, maxEntries) {
  const ordered = Object.entries(entries || {}).sort(
    (a, b) => (Number(b[1]?.updatedAt) || 0) - (Number(a[1]?.updatedAt) || 0)
  );
  return Object.fromEntries(ordered.slice(0, maxEntries));
}

async function readSyncedDecision(scope, key) {
  if (!key) return null;
  try {
    const syncKey = decisionSyncKey(scope, key);
    const result = await chrome.storage.sync.get(syncKey);
    const entry = result[syncKey]?.entries?.[key];
    return entry?.decision || null;
  } catch {
    return null;
  }
}

async function writeSyncedDecision(scope, key, decision) {
  if (!key) return;
  const syncKey = decisionSyncKey(scope, key);
  try {
    const result = await chrome.storage.sync.get(syncKey);
    const current = result[syncKey] || { version: 2, scope, entries: {} };
    current.entries ||= {};
    current.entries[key] = { decision, updatedAt: Date.now() };
    const maxEntries = scope === "source"
      ? MAX_SOURCE_DECISIONS_PER_BUCKET
      : MAX_CONTENT_DECISIONS_PER_BUCKET;
    current.entries = pruneDecisionEntries(current.entries, maxEntries);
    current.updatedAt = Date.now();
    await chrome.storage.sync.set({ [syncKey]: current });
  } catch {
    // Local decisions remain authoritative on this device if sync is unavailable.
  }
}

async function flushDirtyMonths() {
  syncQueue = syncQueue.then(async () => {
    const deviceId = await getDeviceId();
    const state = await readState();
    const retainedMonths = new Set(recentMonthKeys());
    const allDirtyMonths = Object.keys(state.sync.dirtyMonths || {});
    const months = allDirtyMonths.filter((month) => retainedMonths.has(month));
    if (!allDirtyMonths.length) return { ok: true, synced: 0 };

    const payload = {};
    for (const month of months) {
      payload[recordSyncKey(deviceId, month)] = {
        version: 3,
        deviceId,
        month,
        updatedAt: Date.now(),
        languageRecords: extractMonthLanguageRecords(state.languageRecords, month),
        records: extractMonthRecords(state.records, month)
      };
    }

    try {
      if (Object.keys(payload).length) await chrome.storage.sync.set(payload);

      const allSync = await chrome.storage.sync.get(null);
      const staleKeys = Object.keys(allSync).filter((key) => {
        if (!key.startsWith(`${SYNC_RECORD_PREFIX}${deviceId}:`)) return false;
        const month = key.slice(`${SYNC_RECORD_PREFIX}${deviceId}:`.length);
        return !retainedMonths.has(month);
      });
      if (staleKeys.length) await chrome.storage.sync.remove(staleKeys);

      await updateState((latest) => {
        for (const month of allDirtyMonths) delete latest.sync.dirtyMonths[month];
        latest.sync.lastSyncedAt = Date.now();
      });
      return { ok: true, synced: months.length };
    } catch {
      return { ok: false, synced: 0 };
    }
  });
  return syncQueue;
}

function mergeRecordInto(target, dateKey, record) {
  target[dateKey] ||= { active: 0, passive: 0, sites: {} };
  target[dateKey].active += Number(record?.active) || 0;
  target[dateKey].passive += Number(record?.passive) || 0;
  for (const [site, values] of Object.entries(record?.sites || {})) {
    target[dateKey].sites[site] ||= { active: 0, passive: 0 };
    target[dateKey].sites[site].active += Number(values?.active) || 0;
    target[dateKey].sites[site].passive += Number(values?.passive) || 0;
  }
}

async function getCombinedRecords(localState, deviceId, languageCode) {
  const code = normalizeLanguageCode(languageCode);
  if (
    dashboardCache.records &&
    dashboardCache.languageCode === code &&
    Date.now() - dashboardCache.at < 8000
  ) {
    return dashboardCache.records;
  }

  const combined = {};
  try {
    const allSync = await chrome.storage.sync.get(null);
    for (const [key, item] of Object.entries(allSync)) {
      if (!key.startsWith(SYNC_RECORD_PREFIX)) continue;
      if (!item || item.deviceId === deviceId) continue;
      const remoteRecords = item.languageRecords?.[code] || (code === "ja" ? item.records : null) || {};
      for (const [dateKey, record] of Object.entries(remoteRecords)) {
        mergeRecordInto(combined, dateKey, record);
      }
    }
  } catch {
    // Continue with local records only.
  }

  const localRecords = localState.languageRecords?.[code] ||
    (code === "ja" ? localState.records : null) || {};
  for (const [dateKey, record] of Object.entries(localRecords)) {
    mergeRecordInto(combined, dateKey, record);
  }

  dashboardCache = { at: Date.now(), languageCode: code, records: combined };
  return combined;
}

async function isTabActivelyViewed(tabId, status = {}) {
  if (!tabId) return false;
  const pageVisible = status?.pageVisible !== false;
  const pageFocused = status?.pageFocused === true;
  try {
    const tab = await chrome.tabs.get(tabId);
    const windowInfo = await chrome.windows.get(tab.windowId);
    return Boolean(tab.active && pageVisible && (windowInfo.focused || pageFocused));
  } catch {
    return Boolean(pageVisible && pageFocused);
  }
}

function computeStatusState(status, activeImmersion) {
  if (status?.languageState === "awaiting" && status?.playing) return "awaiting";
  if (
    status?.languageState === "confirmed" &&
    status?.countingEligible &&
    !status?.trackingPaused
  ) {
    return activeImmersion ? "recording-active" : "recording-passive";
  }
  return "stopped";
}

async function setBadge(tabId, status) {
  if (!tabId) return;

  let text = "";
  let color = "#475569";
  if (status === "recording-active") {
    text = "A";
    color = "#16a34a";
  } else if (status === "recording-passive") {
    text = "P";
    color = "#f59e0b";
  } else if (status === "awaiting") {
    text = "?";
    color = "#d97706";
  }

  try {
    await chrome.action.setBadgeText({ tabId, text });
    if (text) await chrome.action.setBadgeBackgroundColor({ tabId, color });
  } catch {
    // The tab may have closed.
  }
}

async function refreshTabContext(tabId) {
  const key = String(tabId);
  const existing = liveStatus[key];
  if (!existing) return;
  const activeImmersion = await isTabActivelyViewed(tabId, existing);
  const state = computeStatusState(existing, activeImmersion);
  liveStatus[key] = { ...existing, state, activeImmersion, updatedAt: Date.now() };
  await setBadge(tabId, state);
  try {
    await chrome.tabs.sendMessage(tabId, {
      type: "browserContextChanged",
      activeImmersion,
      computedState: state
    });
  } catch {
    // The content script may not be available yet.
  }
}

async function refreshAllTabContexts() {
  await Promise.all(Object.keys(liveStatus).map((id) => refreshTabContext(Number(id))));
  automaticOwnerTabId = chooseAutomaticOwnerTabId();
}

async function applyRemoteReset(resetAt) {
  if (!resetAt) return;
  await updateState((state) => {
    if ((Number(state.sync.lastResetSeen) || 0) >= resetAt) return;
    const fresh = emptyState();
    fresh.sync.lastResetSeen = resetAt;
    Object.assign(state, fresh);
  });
  for (const key of Object.keys(liveStatus)) delete liveStatus[key];
  automaticOwnerTabId = null;
}

async function checkRemoteReset() {
  try {
    const result = await chrome.storage.sync.get(SYNC_RESET_KEY);
    const resetAt = Number(result[SYNC_RESET_KEY]?.resetAt) || 0;
    if (resetAt) await applyRemoteReset(resetAt);
  } catch {
    // Sync may be unavailable.
  }
}

function ensureSyncAlarm() {
  chrome.alarms.create(SYNC_ALARM, { periodInMinutes: 1 });
  chrome.alarms.create(MANUAL_ALARM, { periodInMinutes: 1 });
  chrome.alarms.create(WEEKLY_REVIEW_ALARM, { when: nextWeeklyReviewAt(), periodInMinutes: 7 * 24 * 60 });
  try {
    chrome.idle.setDetectionInterval(60);
  } catch {
    // Idle detection is a safeguard; the manual controls still work without it.
  }
}

chrome.runtime.onInstalled.addListener(() => {
  ensureSyncAlarm();
  checkRemoteReset();
});

chrome.runtime.onStartup.addListener(() => {
  ensureSyncAlarm();
  checkRemoteReset();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === SYNC_ALARM) flushDirtyMonths();
  if (alarm.name === MANUAL_ALARM) {
    checkpointManualTimer().then((result) => result?.timer?.languageCode && notifyGoalCompletions(result.timer.languageCode));
  }
  if (alarm.name === WEEKLY_REVIEW_ALARM) showWeeklyReview();
});

chrome.idle.onStateChanged.addListener((newState) => {
  if (newState === "idle" || newState === "locked") {
    checkpointManualTimer({ stop: true });
  }
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== "sync") return;
  if (changes[SYNC_RESET_KEY]?.newValue?.resetAt) {
    applyRemoteReset(Number(changes[SYNC_RESET_KEY].newValue.resetAt));
  }
  dashboardCache = { at: 0, languageCode: "", records: null };
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message !== "object" || sender.id !== chrome.runtime.id) return false;
  const tabId = sender.tab?.id;

  if (message.type === "getPreferences") {
    readState().then((state) => sendResponse({ preferences: state.preferences }));
    return true;
  }

  if (message.type === "setPreferences") {
    updateState((state) => {
      if (message.preferences && "autoMinimizeEnabled" in message.preferences) {
        state.preferences.autoMinimizeEnabled = message.preferences.autoMinimizeEnabled !== false;
      }
      if (message.preferences && "autoMinimizeSeconds" in message.preferences) {
        state.preferences.autoMinimizeSeconds = Math.min(300, Math.max(1, Number(message.preferences.autoMinimizeSeconds) || 5));
      }
      if (message.preferences && "notificationsEnabled" in message.preferences) {
        state.preferences.notificationsEnabled = message.preferences.notificationsEnabled !== false;
      }
      if (message.preferences && "theme" in message.preferences) {
        state.preferences.theme = message.preferences.theme === "light" ? "light" : "dark";
      }
      if (message.preferences && "customManualCategories" in message.preferences) {
        state.preferences.customManualCategories = normalizeCustomCategories(message.preferences.customManualCategories);
      }
      if (message.preferences && "onboardingCompleted" in message.preferences) {
        state.preferences.onboardingCompleted = message.preferences.onboardingCompleted === true;
      }
      return { ok: true, preferences: { ...state.preferences } };
    }).then(async (result) => {
      await broadcastOverlayPreferences(result.preferences);
      sendResponse(result);
    });
    return true;
  }

  if (message.type === "setTargetLanguage") {
    updateState((state) => {
      const targetLanguage = normalizeTargetLanguage(message.targetLanguage);
      state.preferences.targetLanguage = targetLanguage;
      state.preferences.languageNames[targetLanguage.code] = targetLanguage.name;
      return { ok: true, targetLanguage, preferences: { ...state.preferences } };
    }).then(async (result) => {
      await broadcastOverlayPreferences(result.preferences);
      sendResponse(result);
    });
    return true;
  }

  if (message.type === "setGoals") {
    updateState((state) => {
      const incoming = message.goals || {};
      const defaults = emptyState().preferences.goals;
      const clampGoalMinutes = (value, fallback) => Math.min(
        525600,
        Math.max(1, Math.round(Number(value) || fallback))
      );
      state.preferences.goals = {
        daily: {
          enabled: true,
          minutes: clampGoalMinutes(incoming.daily?.minutes, defaults.daily.minutes)
        },
        weekly: {
          enabled: true,
          minutes: clampGoalMinutes(incoming.weekly?.minutes, defaults.weekly.minutes)
        },
        monthly: {
          enabled: incoming.monthly?.enabled === true,
          minutes: clampGoalMinutes(incoming.monthly?.minutes, defaults.monthly.minutes)
        },
        yearly: {
          enabled: incoming.yearly?.enabled === true,
          minutes: clampGoalMinutes(incoming.yearly?.minutes, defaults.yearly.minutes)
        }
      };
      return { ok: true, goals: state.preferences.goals };
    }).then(async (result) => {
      try {
        await chrome.storage.sync.set({
          [SYNC_GOALS_KEY]: { goals: result.goals, updatedAt: Date.now() }
        });
      } catch {
        // Goal settings remain available on this device if Chrome Sync is unavailable.
      }
      sendResponse(result);
    });
    return true;
  }

  if (message.type === "setOverlayPosition") {
    updateState((state) => {
      const left = Number(message.position?.left);
      const top = Number(message.position?.top);
      if (!Number.isFinite(left) || !Number.isFinite(top)) return { ok: false };
      state.preferences.overlayPosition = {
        custom: true,
        left: Math.max(0, left),
        top: Math.max(0, top),
        viewportWidth: Math.max(0, Number(message.position?.viewportWidth) || 0),
        viewportHeight: Math.max(0, Number(message.position?.viewportHeight) || 0)
      };
      return { ok: true, position: state.preferences.overlayPosition };
    }).then(sendResponse);
    return true;
  }

  if (message.type === "setUiPreferences") {
    updateState((state) => {
      const validIds = ["session", "calendar-goals", "insights", "manual", "completed", "history"];
      state.preferences.uiLayoutVersion = 2;
      if (Array.isArray(message.componentOrder)) {
        const requested = message.componentOrder.filter((id, index, items) => validIds.includes(id) && items.indexOf(id) === index);
        state.preferences.componentOrder = [...requested, ...validIds.filter((id) => !requested.includes(id))];
      }
      if (message.collapsedComponents && typeof message.collapsedComponents === "object") {
        state.preferences.collapsedComponents = Object.fromEntries(
          validIds.map((id) => [id, message.collapsedComponents[id] === true])
        );
      }
      if (message.historyLimit != null) {
        state.preferences.historyLimit = Number(message.historyLimit) === 10 ? 10 : 5;
      }
      return {
        ok: true,
        componentOrder: state.preferences.componentOrder,
        collapsedComponents: state.preferences.collapsedComponents,
        historyLimit: state.preferences.historyLimit
      };
    }).then(sendResponse);
    return true;
  }

  if (message.type === "exportData") {
    readState().then((state) => sendResponse({ ok: true, state }));
    return true;
  }

  if (message.type === "importData") {
    updateState((state) => {
      const imported = normalizeState(message.state);
      imported.sync.dirtyMonths ||= {};
      for (const records of Object.values(imported.languageRecords || {})) {
        for (const dateKey of Object.keys(records || {})) imported.sync.dirtyMonths[monthKeyFromDateKey(dateKey)] = Date.now();
      }
      Object.assign(state, imported);
      return { ok: true };
    }).then(sendResponse);
    return true;
  }

  if (message.type === "importCsvRows") {
    updateState((state) => {
      const rows = Array.isArray(message.rows) ? message.rows.slice(0, 5000) : [];
      let imported = 0;
      for (const row of rows) {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(String(row.date || ""))) continue;
        const code = normalizeLanguageCode(row.languageCode);
        const site = normalizeManualSource(row.source);
        const active = clampManualSeconds(Number(row.activeSeconds) || 0);
        const passive = clampManualSeconds(Number(row.passiveSeconds) || 0);
        if (!active && !passive) continue;
        const record = ensureRecord(state, row.date, site, code);
        record.active += active;
        record.passive += passive;
        record.sites[site].active += active;
        record.sites[site].passive += passive;
        markMonthDirty(state, row.date);
        const id = "import-" + Date.now() + "-" + imported + "-" + Math.random().toString(36).slice(2, 6);
        addSessionDelta(state, id, {
          kind: "import",
          site,
          title: row.title || site + " imported immersion",
          languageCode: code,
          dateKey: row.date,
          active,
          passive,
          timestamp: new Date(row.date + "T12:00:00").getTime()
        });
        if (row.languageName) state.preferences.languageNames[code] = String(row.languageName).slice(0, 50);
        imported += 1;
      }
      return { ok: true, imported };
    }).then(sendResponse);
    return true;
  }

  if (message.type === "deleteHistorySession") {
    updateState((state) => {
      const id = String(message.sessionId || "");
      const session = state.sessions[id];
      const isLive = state.manualTimer?.running && state.manualTimer.id === id ||
        Object.values(liveStatus).some((status) => status?.sessionId === id);
      if (!session || isLive) return { ok: false, reason: isLive ? "live" : "missing" };
      applySessionContribution(state, session, -1);
      state.lastDeletedSession = { id, session, deletedAt: Date.now() };
      delete state.sessions[id];
      return { ok: true };
    }).then(sendResponse);
    return true;
  }

  if (message.type === "undoHistoryDelete") {
    updateState((state) => {
      const deleted = state.lastDeletedSession;
      if (!deleted?.session || !deleted.id) return { ok: false };
      applySessionContribution(state, deleted.session, 1);
      state.sessions[deleted.id] = deleted.session;
      state.lastDeletedSession = null;
      return { ok: true };
    }).then(sendResponse);
    return true;
  }

  if (message.type === "editHistorySession") {
    updateState((state) => {
      const id = String(message.sessionId || "");
      const session = state.sessions[id];
      const isLive = state.manualTimer?.running && state.manualTimer.id === id ||
        Object.values(liveStatus).some((status) => status?.sessionId === id);
      const dateKey = String(message.date || "");
      if (!session || isLive || !/^\d{4}-\d{2}-\d{2}$/.test(dateKey)) return { ok: false };
      applySessionContribution(state, session, -1);
      session.site = normalizeManualSource(message.source || session.site);
      session.title = String(message.title || session.title || "Immersion session").trim().slice(0, 160);
      session.byDate = {
        [dateKey]: {
          active: clampManualSeconds(message.activeSeconds),
          passive: clampManualSeconds(message.passiveSeconds)
        }
      };
      session.lastAt = Date.now();
      applySessionContribution(state, session, 1);
      return { ok: true };
    }).then(sendResponse);
    return true;
  }

  if (message.type === "addCustomImmersion") {
    const languageCode = normalizeLanguageCode(message.languageCode);
    updateState((state) => {
      const selectedDate = parseLocalDateKey(message.date || localDateKey());
      if (!selectedDate || selectedDate > localDateKey()) return { ok: false, reason: "invalid-date" };
      const timestamp = new Date(selectedDate + "T12:00:00").getTime();
      const code = normalizeLanguageCode(languageCode || state.preferences.targetLanguage.code);
      const source = normalizeManualSource(message.source);
      const action = normalizeManualAction(message.action);
      const mode = normalizeManualMode(message.mode);
      state.preferences.lastManualSource = source;
      state.preferences.lastManualAction = action;
      state.preferences.lastManualMode = mode;
      const added = addManualSeconds(state, { source, mode, seconds: message.seconds, timestamp, languageCode: code });
      if (added) {
        addSessionDelta(state, "custom-" + timestamp + "-" + Math.random().toString(36).slice(2, 8), {
          kind: "custom",
          site: source,
          title: action || source + " immersion",
          languageCode: code,
          dateKey: selectedDate,
          active: mode === "active" ? added : 0,
          passive: mode === "passive" ? added : 0,
          timestamp
        });
      }
      return { ok: Boolean(added), added, languageCode: code, date: selectedDate };
    }).then(async (result) => {
      if (result.ok) await notifyGoalCompletions(result.languageCode);
      sendResponse(result);
    });
    return true;
  }

  if (message.type === "startManualTimer") {
    updateState((state) => {
      if (state.manualTimer?.running) {
        return { ok: true, alreadyRunning: true, timer: manualTimerSnapshot(state.manualTimer) };
      }
      const source = normalizeManualSource(message.source || state.preferences.lastManualSource);
      const action = normalizeManualAction(message.action);
      const mode = normalizeManualMode(message.mode || state.preferences.lastManualMode);
      const now = Date.now();
      const languageCode = normalizeLanguageCode(message.languageCode || state.preferences.targetLanguage.code);
      state.preferences.lastManualSource = source;
      state.preferences.lastManualAction = action;
      state.preferences.lastManualMode = mode;
      state.manualTimer = {
        id: String(now) + "-" + Math.random().toString(36).slice(2, 9),
        source,
        action,
        mode,
        languageCode,
        running: true,
        startedAt: now,
        lastCheckpointAt: now,
        committedSeconds: 0
      };
      return { ok: true, timer: manualTimerSnapshot(state.manualTimer, now) };
    }).then(sendResponse);
    return true;
  }

  if (message.type === "pauseManualTimer") {
    checkpointManualTimer({ stop: true }).then(async (result) => {
      if (result?.timer?.languageCode) await notifyGoalCompletions(result.timer.languageCode);
      sendResponse(result);
    });
    return true;
  }

  if (message.type === "toggleManualTimer") {
    readState().then((state) => {
      if (state.manualTimer?.running) return checkpointManualTimer({ stop: true });
      return updateState((latest) => {
        const source = normalizeManualSource(latest.preferences.lastManualSource);
        const mode = normalizeManualMode(latest.preferences.lastManualMode);
        const languageCode = normalizeLanguageCode(latest.preferences.targetLanguage.code);
        const now = Date.now();
        latest.manualTimer = {
          id: String(now) + "-" + Math.random().toString(36).slice(2, 9),
          source,
          action: "",
          mode,
          languageCode,
          running: true,
          startedAt: now,
          lastCheckpointAt: now,
          committedSeconds: 0
        };
        return { ok: true, timer: manualTimerSnapshot(latest.manualTimer, now) };
      });
    }).then(sendResponse);
    return true;
  }

  if (message.type === "getDecision") {
    (async () => {
      const state = await readState();
      const languageCode = normalizeLanguageCode(message.languageCode || state.preferences.targetLanguage.code);
      const contentStorageKey = message.contentKey
        ? decisionStorageKey(languageCode, message.contentKey)
        : "";
      const sourceStorageKey = message.sourceKey
        ? decisionStorageKey(languageCode, message.sourceKey)
        : "";

      let decision = contentStorageKey
        ? state.decisions.content[contentStorageKey]
        : null;
      if (!decision && sourceStorageKey) {
        decision = state.decisions.source[sourceStorageKey] || null;
      }

      // Existing version 0.5 decisions belonged to Japanese.
      if (!decision && languageCode === "ja" && message.contentKey) {
        decision = state.decisions.content[message.contentKey] || null;
      }
      if (!decision && languageCode === "ja" && message.sourceKey) {
        decision = state.decisions.source[message.sourceKey] || null;
      }

      if (!decision && contentStorageKey) {
        decision = await readSyncedDecision("content", contentStorageKey);
        if (!decision && languageCode === "ja") {
          decision = await readSyncedDecision("content", message.contentKey);
        }
        if (decision) {
          await updateState((latest) => {
            latest.decisions.content[contentStorageKey] = normalizeDecision(decision);
          });
        }
      }
      if (!decision && sourceStorageKey) {
        decision = await readSyncedDecision("source", sourceStorageKey);
        if (!decision && languageCode === "ja") {
          decision = await readSyncedDecision("source", message.sourceKey);
        }
        if (decision) {
          await updateState((latest) => {
            latest.decisions.source[sourceStorageKey] = normalizeDecision(decision);
          });
        }
      }
      return { decision: normalizeDecision(decision) };
    })().then(sendResponse);
    return true;
  }

  if (message.type === "saveDecision") {
    (async () => {
      const scope = message.scope === "source" ? "source" : "content";
      const state = await readState();
      const languageCode = normalizeLanguageCode(message.languageCode || state.preferences.targetLanguage.code);
      const rawKey = scope === "source" ? message.sourceKey : message.contentKey;
      const key = rawKey ? decisionStorageKey(languageCode, rawKey) : "";
      const decision = normalizeDecision(message.decision);
      if (!key || !decision) return { ok: false };

      const sourceLearningKey = message.sourceKey
        ? decisionStorageKey(languageCode, message.sourceKey)
        : "";
      const contentLearningKey = message.contentKey
        ? decisionStorageKey(languageCode, message.contentKey)
        : "";

      const result = await updateState((latest) => {
        latest.decisions[scope][key] = decision;
        let suggestSource = false;

        if (
          scope === "content" &&
          decision === "target" &&
          sourceLearningKey &&
          !latest.decisions.source[sourceLearningKey]
        ) {
          const learning = latest.sourceLearning[sourceLearningKey] ||= {
            confirmedContents: {},
            sourceLabel: message.sourceLabel || "this source",
            languageCode
          };
          learning.confirmedContents[contentLearningKey] = Date.now();
          learning.sourceLabel = message.sourceLabel || learning.sourceLabel;
          suggestSource = Object.keys(learning.confirmedContents).length >= 3;
        }

        if (scope === "source") {
          delete latest.sourceLearning[sourceLearningKey];
        }

        return { ok: true, suggestSource };
      });

      await writeSyncedDecision(scope, key, decision);
      return result;
    })().then(sendResponse);
    return true;
  }

  if (message.type === "dismissSourceSuggestion") {
    updateState((state) => {
      if (message.sourceKey) {
        const languageCode = normalizeLanguageCode(message.languageCode || state.preferences.targetLanguage.code);
        delete state.sourceLearning[decisionStorageKey(languageCode, message.sourceKey)];
      }
      return { ok: true };
    }).then(sendResponse);
    return true;
  }

  if (message.type === "addTick") {
    (async () => {
      if (tabId) {
        try {
          const tab = await chrome.tabs.get(tabId);
          if (tab.mutedInfo?.muted) return { ok: true, ignored: "tab-muted" };
        } catch {
          return { ok: true, ignored: "tab-closed" };
        }
      }

      automaticOwnerTabId = chooseAutomaticOwnerTabId();
      if (tabId && automaticOwnerTabId && automaticOwnerTabId !== tabId) {
        return { ok: true, ignored: "another-video-is-counting" };
      }
      if (tabId && !automaticOwnerTabId) automaticOwnerTabId = tabId;

      return updateState((state) => {
        const active = clampSeconds(message.activeSeconds);
        const passive = clampSeconds(message.passiveSeconds);
        if (!active && !passive) return { ok: true, added: { active: 0, passive: 0 } };

        const site = message.site || "other";
        const languageCode = normalizeLanguageCode(message.languageCode || state.preferences.targetLanguage.code);
        const dateKey = localDateKey(message.timestamp || Date.now());
        const record = ensureRecord(state, dateKey, site, languageCode);

        record.active += active;
        record.passive += passive;
        record.sites[site].active += active;
        record.sites[site].passive += passive;
        markMonthDirty(state, dateKey);

        addSessionDelta(state, message.sessionId, {
          kind: "video",
          site,
          languageCode,
          contentKey: message.contentKey || "",
          title: message.title || "Untitled video",
          startedAt: message.timestamp || Date.now(),
          dateKey,
          active,
          passive
        });

        return { ok: true, added: { active, passive } };
      });
    })().then(async (result) => {
      if (result?.added && !result.ignored) await notifyGoalCompletions(message.languageCode);
      sendResponse(result);
    });
    return true;
  }

  if (message.type === "rollbackSession") {
    updateState((state) => {
      const session = state.sessions[message.sessionId];
      if (!session) return { ok: true, removed: { active: 0, passive: 0 } };

      let removedActive = 0;
      let removedPassive = 0;
      for (const [dateKey, contribution] of Object.entries(session.byDate || {})) {
        const languageCode = normalizeLanguageCode(session.languageCode || "ja");
        const record = state.languageRecords?.[languageCode]?.[dateKey] ||
          (languageCode === "ja" ? state.records?.[dateKey] : null);
        if (!record) continue;
        const site = session.site || "other";
        const siteRecord = record.sites?.[site];

        const active = Number(contribution.active) || 0;
        const passive = Number(contribution.passive) || 0;
        removedActive += active;
        removedPassive += passive;

        record.active = Math.max(0, record.active - active);
        record.passive = Math.max(0, record.passive - passive);
        if (siteRecord) {
          siteRecord.active = Math.max(0, siteRecord.active - active);
          siteRecord.passive = Math.max(0, siteRecord.passive - passive);
        }
        markMonthDirty(state, dateKey);
      }

      delete state.sessions[message.sessionId];
      return { ok: true, removed: { active: removedActive, passive: removedPassive } };
    }).then(sendResponse);
    return true;
  }

  if (message.type === "status") {
    (async () => {
      let tabMuted = false;
      let activeImmersion = false;
      if (tabId) {
        try {
          const tab = await chrome.tabs.get(tabId);
          tabMuted = Boolean(tab.mutedInfo?.muted);
        } catch {
          // Tab may have closed.
        }
        activeImmersion = await isTabActivelyViewed(tabId, message.status);
      }

      const computedState = computeStatusState(message.status, activeImmersion);
      if (tabId) {
        liveStatus[String(tabId)] = {
          ...message.status,
          state: computedState,
          activeImmersion,
          tabMuted,
          updatedAt: Date.now()
        };
        automaticOwnerTabId = chooseAutomaticOwnerTabId();
      }
      await setBadge(tabId, computedState);
      return {
        ok: true,
        tabMuted,
        activeImmersion,
        computedState,
        overlapBlocked: Boolean(automaticOwnerTabId && tabId && automaticOwnerTabId !== tabId)
      };
    })().then(sendResponse);
    return true;
  }

  if (message.type === "getDashboard") {
    (async () => {
      const state = await readState();
      const deviceId = await getDeviceId();
      const languageCode = normalizeLanguageCode(state.preferences.targetLanguage.code);
      const records = await getCombinedRecords(state, deviceId, languageCode);
      try {
        const synced = await chrome.storage.sync.get(SYNC_GOALS_KEY);
        const syncedGoals = synced[SYNC_GOALS_KEY]?.goals;
        if (syncedGoals) {
          const defaults = emptyState().preferences.goals;
          state.preferences.goals = Object.fromEntries(
            Object.entries(defaults).map(([period, goal]) => [
              period,
              {
                ...goal,
                ...(syncedGoals[period] || {}),
                minutes: Math.min(
                  525600,
                  Math.max(1, Math.round(Number(syncedGoals[period]?.minutes) || goal.minutes))
                ),
                enabled: period === "daily" || period === "weekly"
                  ? true
                  : syncedGoals[period]?.enabled === true
              }
            ])
          );
        }
      } catch {
        // Use locally saved goal settings if Chrome Sync is unavailable.
      }
      return {
        state: {
          ...state,
          records,
          manualTimer: manualTimerSnapshot(state.manualTimer),
          currentStatus: { ...liveStatus }
        },
        sync: {
          mode: "chrome-storage-sync",
          deviceId,
          lastSyncedAt: state.sync.lastSyncedAt || 0,
          pendingMonths: Object.keys(state.sync.dirtyMonths || {}).length
        }
      };
    })().then(sendResponse);
    return true;
  }

  if (message.type === "syncNow") {
    flushDirtyMonths().then(sendResponse);
    return true;
  }

  if (message.type === "resetAllData") {
    (async () => {
      const resetAt = Date.now();
      try {
        const allSync = await chrome.storage.sync.get(null);
        const keys = Object.keys(allSync).filter(
          (key) => key.startsWith(SYNC_RECORD_PREFIX) ||
            key.startsWith(SYNC_DECISION_PREFIX) ||
            key === SYNC_GOALS_KEY
        );
        if (keys.length) await chrome.storage.sync.remove(keys);
        await chrome.storage.sync.set({ [SYNC_RESET_KEY]: { resetAt } });
      } catch {
        // Local reset still succeeds.
      }

      const fresh = emptyState();
      fresh.sync.lastResetSeen = resetAt;
      await chrome.storage.local.set({ [LOCAL_STATE_KEY]: fresh });
      for (const key of Object.keys(liveStatus)) delete liveStatus[key];
      dashboardCache = { at: 0, languageCode: "", records: null };
      return { ok: true };
    })().then(sendResponse);
    return true;
  }

  return false;
});

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  return tab || null;
}

async function sendToActiveTab(message) {
  const tab = await getActiveTab();
  if (!tab?.id) return null;
  try {
    return await chrome.tabs.sendMessage(tab.id, message);
  } catch {
    return null;
  }
}

chrome.commands.onCommand.addListener(async (command) => {
  if (command === "toggle-manual-timer") {
    const state = await readState();
    if (state.manualTimer?.running) {
      await checkpointManualTimer({ stop: true });
    } else {
      await updateState((latest) => {
        const now = Date.now();
        latest.manualTimer = {
          id: String(now) + "-" + Math.random().toString(36).slice(2, 9),
          source: normalizeManualSource(latest.preferences.lastManualSource),
          action: "",
          mode: normalizeManualMode(latest.preferences.lastManualMode),
          languageCode: normalizeLanguageCode(latest.preferences.targetLanguage.code),
          running: true,
          startedAt: now,
          lastCheckpointAt: now,
          committedSeconds: 0
        };
      });
    }
    return;
  }

  if (command === "toggle-video-tracking") {
    await sendToActiveTab({ type: "toggleTrackerPause" });
    return;
  }

  if (command === "toggle-status-overlay") {
    await sendToActiveTab({ type: "toggleOverlayCompact" });
    return;
  }

  if (command === "show-hotkeys") {
    await chrome.storage.session.set({ [HOTKEY_GUIDE_REQUEST_KEY]: Date.now() });
    try {
      await chrome.action.openPopup();
    } catch {
      await chrome.tabs.create({ url: chrome.runtime.getURL("popup.html?hotkeys=1") });
    }
  }
});

chrome.tabs.onActivated.addListener(() => refreshAllTabContexts());
chrome.windows.onFocusChanged.addListener(() => refreshAllTabContexts());
chrome.tabs.onRemoved.addListener((tabId) => {
  delete liveStatus[String(tabId)];
  if (automaticOwnerTabId === tabId) automaticOwnerTabId = chooseAutomaticOwnerTabId();
});

ensureSyncAlarm();
checkRemoteReset();
