(() => {
  const STREAMING_SITE_CONFIGS = [
    {
      id: "netflix", name: "Netflix", hosts: [/^(?:www\.)?netflix\.com$/],
      routes: [/^\/watch\/[^/?#]+/], brand: /\s*[-|]\s*Netflix\s*$/i,
      titleSelectors: ['[data-uia="video-title"]', ".video-title", ".ellipsize-text h4"],
      seriesSelectors: ['[data-uia="video-title"] h4', ".video-title h4", ".ellipsize-text h4"]
    },
    {
      id: "disneyplus", name: "Disney+", hosts: [/^(?:www\.)?disneyplus\.com$/],
      routes: [/^\/(?:[a-z]{2}-[a-z]{2}\/)?(?:play|video)\//i], brand: /\s*[-|]\s*Disney\+\s*$/i,
      titleSelectors: ['[data-testid*="title"]', '[class*="title"] h1', "h1"],
      seriesSelectors: ['[data-testid="player-title"]', '[data-testid*="series-title"]', "h1"]
    },
    {
      id: "primevideo", name: "Prime Video",
      hosts: [/^(?:www\.)?primevideo\.com$/, /^(?:www\.)?amazon\.(?:com|co\.uk|ca|de|co\.jp|fr|it|es)$/],
      routes: [/\/(?:detail|gp\/video\/detail)\//i], brand: /\s*[-|:]\s*(?:Prime Video|Amazon\.com)\s*$/i,
      titleSelectors: ['[data-automation-id="title"]', '[class*="atvwebplayersdk-title"]', "h1"],
      seriesSelectors: ['[data-automation-id="title"]', '[class*="atvwebplayersdk-title-text"]', "h1"]
    },
    {
      id: "hulu", name: "Hulu", hosts: [/^(?:www\.)?hulu\.com$/],
      routes: [/^\/watch\//i], brand: /\s*[-|]\s*Hulu\s*$/i,
      titleSelectors: ['[data-testid="player-title"]', '[class*="PlayerMetadata"]', "h1"],
      seriesSelectors: ['[data-testid="player-title"]', '[class*="PlayerMetadata__title"]', "h1"]
    },
    {
      id: "max", name: "Max", hosts: [/^play\.max\.com$/],
      routes: [/\/(?:video\/watch|watch)\//i], brand: /\s*[-|]\s*Max\s*$/i,
      titleSelectors: ['[data-testid*="content-title"]', '[data-testid*="player-title"]', "h1"],
      seriesSelectors: ['[data-testid*="series-title"]', '[data-testid*="content-title"]', "h1"]
    },
    {
      id: "appletv", name: "Apple TV+", hosts: [/^tv\.apple\.com$/],
      routes: [/\/(?:episode|movie)\//i], brand: /\s*[-|]\s*Apple TV(?:\+)?\s*$/i,
      contentTypeRoutes: [
        { pattern: /\/episode\//i, type: "tv_show" },
        { pattern: /\/movie\//i, type: "movie" }
      ],
      titleSelectors: ['[data-testid*="title"]', '[class*="title"] h1', "h1"],
      seriesSelectors: ['[data-testid*="show-title"]', '[class*="show-title"]', "h1"]
    },
    {
      id: "paramountplus", name: "Paramount+", hosts: [/^(?:www\.)?paramountplus\.com$/],
      routes: [/\/(?:shows|movies)\/video\//i, /\/live-tv\//i], brand: /\s*[-|]\s*Paramount\+\s*$/i,
      contentTypeRoutes: [
        { pattern: /\/shows\//i, type: "tv_show" },
        { pattern: /\/movies\//i, type: "movie" },
        { pattern: /\/live-tv\//i, type: "tv_show" }
      ],
      titleSelectors: ['[data-testid*="title"]', '[class*="video-title"]', "h1"],
      seriesSelectors: ['[data-testid*="show-title"]', '[class*="show-title"]', "h1"]
    },
    {
      id: "peacock", name: "Peacock", hosts: [/^(?:www\.)?peacocktv\.com$/],
      routes: [/\/watch\//i], brand: /\s*[-|]\s*Peacock(?: TV)?\s*$/i,
      titleSelectors: ['[data-testid*="title"]', '[class*="metadata"] h1', "h1"],
      seriesSelectors: ['[data-testid*="series-title"]', '[data-testid*="title"]', "h1"]
    },
    {
      id: "crunchyroll", name: "Crunchyroll", hosts: [/^(?:www\.)?crunchyroll\.com$/],
      routes: [/\/watch\//i], brand: /\s*[-|]\s*Crunchyroll\s*$/i,
      titleSelectors: ['[data-testid*="title"]', '[class*="show-title"]', "h1"],
      seriesSelectors: ['[data-testid*="series-title"]', '[class*="show-title"]', 'a[href*="/series/"]', "h1"]
    },
    {
      id: "hidive", name: "HIDIVE", hosts: [/^(?:www\.)?hidive\.com$/],
      routes: [/\/(?:video|stream)\//i], brand: /\s*[-|]\s*HIDIVE\s*$/i,
      titleSelectors: ['[class*="video-title"]', '[class*="player-title"]', "h1"],
      seriesSelectors: ['[class*="series-title"]', '[class*="show-title"]', "h1"]
    },
    {
      id: "tubi", name: "Tubi", hosts: [/^(?:www\.)?tubitv\.com$/],
      routes: [/\/(?:movies|tv-shows)\//i], brand: /\s*[-|]\s*Tubi(?: TV)?\s*$/i,
      contentTypeRoutes: [
        { pattern: /\/tv-shows\//i, type: "tv_show" },
        { pattern: /\/movies\//i, type: "movie" }
      ],
      titleSelectors: ['[data-testid*="title"]', '[class*="video-title"]', "h1"],
      seriesSelectors: ['[data-testid*="series-title"]', '[class*="series-title"]', "h1"]
    }
  ];

  const streamingSite = STREAMING_SITE_CONFIGS.find((candidate) =>
    candidate.hosts.some((pattern) => pattern.test(location.hostname))
  ) || null;
  const site = streamingSite?.id || "youtube";
  const isStreamingSite = Boolean(streamingSite);
  let targetLanguage = { code: "ja", name: "Japanese" };

  let currentVideo = null;
  let currentInfo = null;
  let currentUrl = location.href;
  let sessionId = null;
  let languageState = "checking";
  let detectionReason = "";
  let pageProbe = { hints: [], captions: [], audioTracks: [] };
  let lastStreamingAudioSignature = "";

  // --- Content-type detection (movie vs. tv_show) state ---
  // contentTypeMemory caches resolved results (any tier) per titleKey for the
  // life of the page so we don't re-hit storage or re-prompt on every poll.
  const contentTypeMemory = new Map();
  const pendingContentTypeKeys = new Set();
  let contentTypePrompt = null; // { titleKey, titleLabel, resolve } while Tier 3 is on screen
  let pendingLanguageStepKey = ""; // labels only the matching title's immediate language prompt as step 2
  let ogJsonLdDirty = true;
  let ogJsonLdSnapshot = { ogType: null, candidates: [] };
  let ogJsonLdDebounceTimer = null;

  let lastSampleWall = 0;
  let lastMediaTime = 0;
  let pendingActive = 0;
  let pendingPassive = 0;
  let sessionActive = 0;
  let sessionPassive = 0;
  let lastFlushAt = performance.now();
  let statusPausedByUser = false;
  let browserTabMuted = false;
  let browserContextActive = true;
  let sourceSuggestion = false;
  let overlayCompact = false;
  let overlayManuallyShown = false;
  let overlayDragState = null;
  let suppressOverlayClick = false;
  let autoMinimizeTimer = null;
  let overlayPreferences = {
    autoMinimizeEnabled: true,
    autoMinimizeSeconds: 5,
    theme: "dark"
  };

  const overlay = createOverlay();
  initializeOverlayDragging();

  function randomId() {
    return `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
  }

  function sendMessage(message) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(message, (response) => {
          if (chrome.runtime.lastError) return resolve(null);
          resolve(response || null);
        });
      } catch {
        resolve(null);
      }
    });
  }

  function injectYouTubeProbe() {
    if (site !== "youtube" || document.documentElement.dataset.jitProbeInjected) return;
    document.documentElement.dataset.jitProbeInjected = "true";
    const script = document.createElement("script");
    script.src = chrome.runtime.getURL("page-probe.js");
    script.onload = () => script.remove();
    (document.head || document.documentElement).appendChild(script);
  }

  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    if (event.data?.source !== "language-immersion-tracker") return;
    if (event.data?.type !== "youtube-probe") return;
    pageProbe = event.data.data || { hints: [], captions: [], audioTracks: [] };

    // Player metadata often arrives after playback starts. Re-evaluate
    // candidates, and immediately dismiss a prompt if another primary language
    // becomes clear.
    if (
      currentInfo &&
      isVideoPlaying(currentVideo) &&
      ["checking", "awaiting", "not-candidate", "primary-other"].includes(languageState)
    ) {
      applyDetectionResult(detectTargetLanguage(currentInfo));
    }
  });

  function getYouTubeVideoId() {
    const url = new URL(location.href);
    if (location.pathname === "/watch") {
      return url.searchParams.get("v")?.trim() || "";
    }

    const routeMatch = location.pathname.match(/^\/(?:shorts|live|embed)\/([^/?#]+)/);
    return routeMatch?.[1] || "";
  }

  function getYouTubeInfo() {
    const urlVideoId = getYouTubeVideoId();
    if (!urlVideoId) return null;

    const probeMatchesVideo = !pageProbe.videoId || pageProbe.videoId === urlVideoId;
    const title =
      document.querySelector("h1 ytd-watch-metadata yt-formatted-string")?.textContent?.trim() ||
      document.querySelector("h1.title yt-formatted-string")?.textContent?.trim() ||
      (probeMatchesVideo ? pageProbe.title : "") ||
      document.title.replace(/\s*-\s*YouTube\s*$/, "") ||
      "YouTube video";
    const channel =
      document.querySelector("#owner #channel-name a")?.textContent?.trim() ||
      document.querySelector("ytd-video-owner-renderer #channel-name a")?.textContent?.trim() ||
      (probeMatchesVideo ? pageProbe.author : "") ||
      "";
    const channelId = probeMatchesVideo ? (pageProbe.channelId || "") : "";

    return {
      site: "youtube",
      contentKey: `youtube:${urlVideoId}`,
      sourceKey: channelId
        ? `youtube-channel:${channelId}`
        : channel
          ? `youtube-channel-name:${channel.toLowerCase()}`
          : "",
      title,
      sourceLabel: channel || "this channel"
    };
  }

  function compactText(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  function isLikelyPlaybackMetadataElement(element) {
    if (!element) return false;
    let current = element;
    for (let depth = 0; current && depth < 7; depth += 1, current = current.parentElement) {
      const identity = [
        typeof current.className === "string" ? current.className : "",
        current.id,
        current.getAttribute?.("data-testid"),
        current.getAttribute?.("data-uia"),
        current.getAttribute?.("aria-label")
      ].filter(Boolean).join(" ");
      if (/recommend|carousel|suggest|related|more[-_\s]?like|content[-_\s]?rail/i.test(identity)) return false;
      if (current.hidden || current.getAttribute?.("aria-hidden") === "true") return false;
    }
    return true;
  }

  function firstText(selectors) {
    for (const selector of selectors || []) {
      let elements = [];
      try {
        elements = [...document.querySelectorAll(selector)].slice(0, 8);
      } catch {
        continue;
      }
      const element = elements.find(isLikelyPlaybackMetadataElement);
      const text = compactText(element?.innerText || element?.textContent || element?.getAttribute?.("aria-label"));
      if (text) return text;
    }
    return "";
  }

  function allMetadataText(config) {
    const selectors = [
      ...(config.titleSelectors || []),
      ...(config.seriesSelectors || []),
      '[data-uia*="episode"]', '[data-uia*="season"]',
      '[data-testid*="episode"]', '[data-testid*="season"]',
      '[class*="episode-title"]', '[class*="EpisodeTitle"]',
      '[class*="season-title"]', '[class*="SeasonTitle"]',
      '[aria-label*="Episode"]', '[aria-label*="Season"]'
    ];
    const values = [];
    for (const selector of selectors) {
      let elements = [];
      try {
        elements = [...document.querySelectorAll(selector)].slice(0, 8);
      } catch {
        continue;
      }
      for (const element of elements) {
        if (!isLikelyPlaybackMetadataElement(element)) continue;
        const text = compactText(element.innerText || element.textContent || element.getAttribute("aria-label"));
        if (text && text.length <= 500) values.push(text);
      }
    }
    return [...new Set(values)].join(" | ");
  }

  function cleanStreamingTitle(value, config) {
    let title = compactText(value);
    title = title.replace(config.brand, "").trim();
    title = title.replace(/^watch\s+/i, "").replace(/^stream\s+/i, "").trim();
    return title.replace(/^[-|:\s]+|[-|:\s]+$/g, "").trim();
  }

  function stableKeyPart(value) {
    return compactText(value).toLocaleLowerCase()
      .normalize("NFKD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^\p{L}\p{N}]+/gu, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 160) || "unknown";
  }

  const NUMBERED_CONTENT_TERMS = {
    ja: { season: ["シーズン"], episode: ["エピソード", "話"] },
    en: { season: ["season"], episode: ["episode"] },
    sv: { season: ["säsong"], episode: ["avsnitt"] },
    es: { season: ["temporada"], episode: ["episodio", "capítulo"] },
    fr: { season: ["saison"], episode: ["épisode"] },
    de: { season: ["staffel"], episode: ["folge", "episode"] },
    it: { season: ["stagione"], episode: ["episodio", "puntata"] },
    pt: { season: ["temporada"], episode: ["episódio", "capítulo"] },
    ko: { season: ["시즌"], episode: ["에피소드", "화"] },
    zh: { season: ["季"], episode: ["集"] },
    ru: { season: ["сезон"], episode: ["серия", "эпизод"] },
    uk: { season: ["сезон"], episode: ["серія", "епізод"] },
    ar: { season: ["موسم", "الموسم"], episode: ["حلقة", "الحلقة"] },
    hi: { season: ["सीज़न", "सीजन"], episode: ["एपिसोड", "कड़ी"] },
    tr: { season: ["sezon"], episode: ["bölüm"] },
    pl: { season: ["sezon"], episode: ["odcinek"] },
    nl: { season: ["seizoen"], episode: ["aflevering"] },
    da: { season: ["sæson"], episode: ["afsnit", "episode"] },
    no: { season: ["sesong"], episode: ["episode"] },
    fi: { season: ["kausi"], episode: ["jakso"] },
    vi: { season: ["mùa"], episode: ["tập"] },
    th: { season: ["ซีซัน", "ฤดูกาล"], episode: ["ตอน"] },
    id: { season: ["musim"], episode: ["episode"] },
    ms: { season: ["musim"], episode: ["episod"] },
    tl: { season: ["season", "panahon"], episode: ["episode", "yugto"] },
    el: { season: ["σεζόν", "κύκλος"], episode: ["επεισόδιο"] },
    he: { season: ["עונה"], episode: ["פרק"] },
    fa: { season: ["فصل"], episode: ["قسمت"] },
    bn: { season: ["সিজন"], episode: ["পর্ব"] },
    ur: { season: ["سیزن"], episode: ["قسط"] },
    cs: { season: ["série", "řada"], episode: ["epizoda", "díl"] },
    ro: { season: ["sezon"], episode: ["episod"] },
    hu: { season: ["évad"], episode: ["epizód", "rész"] },
    bg: { season: ["сезон"], episode: ["епизод"] },
    hr: { season: ["sezona"], episode: ["epizoda"] },
    sr: { season: ["sezona", "сезона"], episode: ["epizoda", "епизода"] },
    sk: { season: ["séria"], episode: ["epizóda"] },
    sl: { season: ["sezona"], episode: ["epizoda", "del"] },
    et: { season: ["hooaeg"], episode: ["osa"] },
    lv: { season: ["sezona"], episode: ["sērija"] },
    lt: { season: ["sezonas"], episode: ["serija"] },
    is: { season: ["tímabil", "sería", "þáttaröð"], episode: ["þáttur"] },
    sw: { season: ["msimu"], episode: ["kipindi"] },
    ca: { season: ["temporada"], episode: ["episodi", "capítol"] },
    eu: { season: ["denboraldi"], episode: ["atal"] },
    gl: { season: ["tempada"], episode: ["episodio", "capítulo"] },
    cy: { season: ["tymor"], episode: ["pennod"] },
    ga: { season: ["séasúr"], episode: ["eipeasóid"] }
  };

  function escapePattern(value) {
    return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  function termsFor(kind) {
    return [...new Set(Object.values(NUMBERED_CONTENT_TERMS).flatMap((entry) => entry[kind]))]
      .sort((a, b) => b.length - a.length);
  }

  const SEASON_TERMS_PATTERN = termsFor("season").map(escapePattern).join("|");
  const EPISODE_TERMS_PATTERN = termsFor("episode").map(escapePattern).join("|");

  function numberedTermMatch(value, pattern, maxDigits = 4) {
    const text = String(value || "");
    const termFirst = new RegExp(
      `(?<![\\p{L}\\p{N}])(?:${pattern})\\s*[:.#-]?\\s*(\\d{1,${maxDigits}})(?!\\d)`,
      "iu"
    ).exec(text);
    const numberFirst = new RegExp(
      `(?<!\\d)(?:第\\s*)?(\\d{1,${maxDigits}})\\s*(?:${pattern})(?![\\p{L}\\p{N}])`,
      "iu"
    ).exec(text);
    if (!termFirst) return numberFirst;
    if (!numberFirst) return termFirst;
    return termFirst.index <= numberFirst.index ? termFirst : numberFirst;
  }

  function extractSeasonNumber(value) {
    const named = numberedTermMatch(value, SEASON_TERMS_PATTERN, 3);
    if (named) return String(Number(named[1]));
    const compact = String(value || "").match(/S(\d{1,3})\s*[:.-]?\s*E\d{1,4}/i);
    return compact ? String(Number(compact[1])) : "";
  }

  function hasEpisodeMarker(value) {
    return Boolean(numberedTermMatch(value, EPISODE_TERMS_PATTERN, 4)) ||
      /S\d{1,3}\s*[:.-]?\s*E\d{1,4}/i.test(value) ||
      /(?:^|[\s|])E\d{1,4}(?:\.\d+)?\s*[-–—:]/i.test(value);
  }

  function seriesNameFrom(value) {
    const firstLine = compactText(String(value || "").split(/[\n|]/)[0]);
    const matches = [
      numberedTermMatch(firstLine, SEASON_TERMS_PATTERN, 3),
      numberedTermMatch(firstLine, EPISODE_TERMS_PATTERN, 4),
      /S\d{1,3}\s*[:.-]?\s*E\d{1,4}/i.exec(firstLine)
    ].filter((match) => match && match.index > 0);
    if (!matches.length) return firstLine;
    const cutAt = Math.min(...matches.map((match) => match.index));
    return firstLine.slice(0, cutAt).replace(/\s*[-–—:|]+\s*$/, "").trim();
  }

  // ---------------------------------------------------------------------
  // Content-type detection: movie vs. tv_show.
  //
  // Contract: detectContentType-style resolution always returns either
  //   { type, source, confidence } or null (unresolved).
  // Tier 1 and Tier 2 may ONLY return a result on a positive match. Absence
  // of evidence must fall through to the next tier -- it must never be
  // treated as "movie". Only Tier 2's explicit video.movie/Movie match or
  // Tier 3's explicit user answer may produce type: "movie".
  // ---------------------------------------------------------------------

  const CONTENT_TYPE_TAGS = {
    movie: new Set(["video.movie", "movie"]),
    tv_show: new Set([
      "video.tv_show", "video.episode",
      "tvseries", "tvseason", "tvepisode", "creativeworkseries"
    ])
  };

  function normalizeContentTypeTag(raw) {
    const value = String(raw || "").trim().toLowerCase();
    if (!value) return null;
    if (CONTENT_TYPE_TAGS.movie.has(value)) return "movie";
    if (CONTENT_TYPE_TAGS.tv_show.has(value)) return "tv_show";
    return null;
  }

  // Tier 1: use explicit playback-route and season/episode signals. Only a
  // positive match returns a result; lack of evidence must remain unresolved.
  function tier1PageSignals(config, pathname, seasonNumber, metadata) {
    const routeMatch = (config?.contentTypeRoutes || []).find(({ pattern }) => pattern.test(pathname));
    if (routeMatch) return { type: routeMatch.type, source: "route", confidence: "high" };
    if (seasonNumber) return { type: "tv_show", source: "season_text", confidence: "high" };
    if (hasEpisodeMarker(metadata)) return { type: "tv_show", source: "season_text", confidence: "high" };
    return null;
  }

  function normalizedComparableTitle(value) {
    return compactText(value).toLocaleLowerCase().normalize("NFKD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^\p{L}\p{N}]+/gu, " ")
      .trim();
  }

  function contentTypeCandidateFromNode(node, root = false) {
    if (!node || typeof node !== "object" || Array.isArray(node)) return null;
    const rawTypes = [].concat(node["@type"] || []);
    const type = rawTypes.map(normalizeContentTypeTag).find(Boolean);
    if (!type) return null;
    const seriesValue = node.partOfSeries || node.isPartOf;
    const seriesTitle = typeof seriesValue === "string"
      ? compactText(seriesValue)
      : compactText(seriesValue?.name || seriesValue?.headline);
    const urls = [
      node.url,
      node["@id"],
      typeof node.mainEntityOfPage === "string" ? node.mainEntityOfPage : node.mainEntityOfPage?.["@id"]
    ].map((value) => String(value || "").trim()).filter(Boolean);
    return {
      type,
      rawType: rawTypes.find((value) => normalizeContentTypeTag(value)) || "",
      name: compactText(node.name || node.headline),
      seriesTitle,
      urls,
      root
    };
  }

  function collectContentTypeCandidates(parsed) {
    const candidates = [];
    const visited = new Set();
    let inspected = 0;
    function visit(value, depth = 0, root = false) {
      if (!value || depth > 5 || inspected >= 100) return;
      if (Array.isArray(value)) {
        for (const item of value) visit(item, depth + 1, root);
        return;
      }
      if (typeof value !== "object" || visited.has(value)) return;
      visited.add(value);
      inspected += 1;
      const candidate = contentTypeCandidateFromNode(value, root);
      if (candidate) candidates.push(candidate);
      for (const [key, child] of Object.entries(value)) {
        if (key === "@context") continue;
        if (child && typeof child === "object") visit(child, depth + 1, false);
      }
    }
    visit(parsed, 0, true);
    return candidates;
  }

  // Tier 2: cache page metadata candidates, then match them to the current
  // playback title. This prevents an unrelated carousel's JSON-LD from
  // classifying the video that is actually playing.
  function recomputeOgJsonLdTier() {
    ogJsonLdDirty = false;
    ogJsonLdSnapshot = { ogType: null, candidates: [] };

    try {
      const ogType = document.querySelector('meta[property="og:type"]')?.getAttribute("content");
      const fromOg = normalizeContentTypeTag(ogType);
      if (fromOg) {
        ogJsonLdSnapshot.ogType = { type: fromOg, rawType: ogType };
      }
    } catch {
      // Malformed/missing meta tag: JSON-LD may still provide evidence.
    }

    try {
      const scripts = [...document.querySelectorAll('script[type="application/ld+json"]')].slice(0, 12);
      for (const script of scripts) {
        let parsed;
        try {
          parsed = JSON.parse(script.textContent || "");
        } catch {
          continue;
        }
        ogJsonLdSnapshot.candidates.push(...collectContentTypeCandidates(parsed));
      }
    } catch {
      // Malformed structured data: no evidence, remain unresolved.
    }
  }

  function scheduleOgJsonLdRescan() {
    ogJsonLdDirty = true;
    if (ogJsonLdDebounceTimer) return;
    ogJsonLdDebounceTimer = setTimeout(() => {
      ogJsonLdDebounceTimer = null;
      recomputeOgJsonLdTier();
    }, 400);
  }

  // SPA sites (Netflix, Prime Video, etc.) swap <head> metadata and use
  // history.pushState instead of full navigations, so a one-time read on
  // load would go stale. Watch for both.
  function mutationContainsStructuredData(mutation) {
    if (mutation.type === "attributes") {
      return mutation.target?.matches?.('meta[property="og:type"], script[type="application/ld+json"]');
    }
    if (mutation.type === "characterData") {
      return mutation.target?.parentElement?.matches?.('script[type="application/ld+json"]');
    }
    if (mutation.target?.matches?.('meta[property="og:type"], script[type="application/ld+json"]')) return true;
    return [...mutation.addedNodes, ...mutation.removedNodes].some((node) =>
      node?.matches?.('meta[property="og:type"], script[type="application/ld+json"]') ||
      node?.querySelector?.('meta[property="og:type"], script[type="application/ld+json"]')
    );
  }

  function watchHeadForContentTypeTags() {
    if (!isStreamingSite || !document.head) return;
    try {
      new MutationObserver((mutations) => {
        if (mutations.some(mutationContainsStructuredData)) scheduleOgJsonLdRescan();
      }).observe(document.documentElement, {
        childList: true,
        subtree: true,
        attributes: true,
        characterData: true,
        attributeFilter: ["content", "property", "type"]
      });
    } catch {
      // History navigation still marks the metadata cache dirty.
    }

    for (const methodName of ["pushState", "replaceState"]) {
      const original = history[methodName];
      if (typeof original !== "function") continue;
      if (original.__immersionTrackerPatched) continue;
      const patched = function patchedHistoryMethod(...args) {
        const result = original.apply(this, args);
        scheduleOgJsonLdRescan();
        return result;
      };
      patched.__immersionTrackerPatched = true;
      history[methodName] = patched;
    }
    window.addEventListener("popstate", scheduleOgJsonLdRescan);
  }

  function metadataUrlMatchesCurrentPage(value) {
    try {
      const candidate = new URL(value, location.href);
      return candidate.origin === location.origin &&
        candidate.pathname.replace(/\/+$/, "") === location.pathname.replace(/\/+$/, "");
    } catch {
      return false;
    }
  }

  function candidateMatchScore(candidate, title, seriesTitle) {
    const currentNames = [title, seriesTitle].map(normalizedComparableTitle).filter(Boolean);
    const candidateNames = [candidate.name, candidate.seriesTitle]
      .map(normalizedComparableTitle).filter(Boolean);
    let score = candidate.urls.some(metadataUrlMatchesCurrentPage) ? 120 : 0;
    for (const candidateName of candidateNames) {
      for (const currentName of currentNames) {
        if (candidateName === currentName) score = Math.max(score, 110);
        else if (
          candidateName.length >= 6 && currentName.length >= 6 &&
          (candidateName.includes(currentName) || currentName.includes(candidateName))
        ) score = Math.max(score, 70);
      }
    }
    if (!candidateNames.length && candidate.root) score = Math.max(score, 55);
    return score;
  }

  function tier2OgJsonLd({ title = "", seriesTitle = "" } = {}) {
    if (ogJsonLdDirty) recomputeOgJsonLdTier();
    if (ogJsonLdSnapshot.ogType) {
      const result = {
        type: ogJsonLdSnapshot.ogType.type,
        source: "og_jsonld",
        confidence: "medium",
        raw: `og:type="${ogJsonLdSnapshot.ogType.rawType}"`
      };
      console.debug("[immersion-tracker] content-type tier2 matched", result);
      return result;
    }

    const ranked = ogJsonLdSnapshot.candidates
      .map((candidate) => ({ candidate, score: candidateMatchScore(candidate, title, seriesTitle) }))
      .filter(({ score }) => score >= 50)
      .sort((a, b) => b.score - a.score);
    if (!ranked.length) return null;
    if (ranked[1] && ranked[1].score === ranked[0].score &&
        ranked[1].candidate.type !== ranked[0].candidate.type) return null;
    const best = ranked[0].candidate;
    const result = {
      type: best.type,
      source: "og_jsonld",
      confidence: "medium",
      seriesTitle: best.seriesTitle,
      raw: `ld+json @type="${best.rawType}"`
    };
    console.debug("[immersion-tracker] content-type tier2 matched", result);
    return result;
  }

  // Tier 3: manual prompt, reusing the existing overlay card UI. Returns a
  // Promise that resolves once the user answers or an already-remembered
  // decision is loaded from storage. Deduplicated per titleKey so a title
  // already being resolved (or already answered) is never re-prompted.
  async function ensureContentType(titleKey, titleLabel) {
    if (contentTypeMemory.has(titleKey)) return contentTypeMemory.get(titleKey);
    if (pendingContentTypeKeys.has(titleKey)) return null;
    pendingContentTypeKeys.add(titleKey);

    try {
      const stored = await sendMessage({ type: "getContentType", titleKey });
      if (stored?.contentType === "movie" || stored?.contentType === "tv_show") {
        const result = { type: stored.contentType, source: "manual", confidence: "user_confirmed" };
        contentTypeMemory.set(titleKey, result);
        return result;
      }

      const answer = await promptForContentType(titleKey, titleLabel);
      if (!answer) return null;
      const result = { type: answer, source: "manual", confidence: "user_confirmed" };
      contentTypeMemory.set(titleKey, result);
      await sendMessage({ type: "saveContentType", titleKey, contentType: answer });
      return result;
    } finally {
      pendingContentTypeKeys.delete(titleKey);
    }
  }

  function promptForContentType(titleKey, titleLabel) {
    return new Promise((resolve) => {
      if (contentTypePrompt) contentTypePrompt.resolve(null);
      contentTypePrompt = { titleKey, titleLabel, resolve };
      overlayCompact = false;
      overlayManuallyShown = true;
      overlay.host.style.display = "block";
      renderOverlay();
    });
  }

  function cancelContentTypePrompt() {
    const prompt = contentTypePrompt;
    if (!prompt) return;
    contentTypePrompt = null;
    prompt.resolve(null);
  }

  function resolveContentTypePrompt(type) {
    const prompt = contentTypePrompt;
    if (!prompt) return;
    contentTypePrompt = null;
    pendingLanguageStepKey = prompt.titleKey;
    prompt.resolve(type);
  }

  function getStreamingInfo() {
    if (!streamingSite) return null;
    const knownPlaybackRoute = streamingSite.routes.some((pattern) => pattern.test(location.pathname));
    if (!knownPlaybackRoute) {
      const audiblePlayingVideo = [...document.querySelectorAll("video")].some((video) => {
        const rect = video.getBoundingClientRect();
        const area = Math.max(0, rect.width) * Math.max(0, rect.height);
        return isVideoPlaying(video) && !video.muted && video.volume > 0 &&
          area >= Math.max(80000, window.innerWidth * window.innerHeight * 0.2);
      });
      if (!audiblePlayingVideo) return null;
    }

    const selectedTitle = firstText(streamingSite.titleSelectors);
    const pageTitle = cleanStreamingTitle(document.title, streamingSite);
    const title = selectedTitle || pageTitle || `${streamingSite.name} video`;
    const metadata = [allMetadataText(streamingSite), title, pageTitle, location.pathname]
      .filter(Boolean).join(" | ");
    const seasonNumber = extractSeasonNumber(metadata);
    const selectedSeries = firstText(streamingSite.seriesSelectors);
    const initialSeriesTitle = seriesNameFrom(selectedSeries || title || pageTitle) || title;
    const tier1Result = tier1PageSignals(streamingSite, location.pathname, seasonNumber, metadata);
    const tier2Result = tier1Result ? null : tier2OgJsonLd({ title, seriesTitle: initialSeriesTitle });
    const seriesTitle = seriesNameFrom(tier2Result?.seriesTitle || initialSeriesTitle) || title;

    // Season/episode-independent key, since a title's season count (and
    // therefore whether Tier 1 text is present) can change between visits
    // (e.g. a show renewed for a second season). Movie vs. tv_show is a
    // property of the title, not of any one season.
    const titleKey = `${site}:type:${stableKeyPart(seriesTitle)}`;

    // Tier 1 (season/episode text) -> Tier 2 (OG/JSON-LD) -> Tier 3 (cached
    // manual answer, if already resolved earlier this session). Tier 3's
    // interactive prompt itself is triggered separately from refreshContext,
    // since it's async and this function must stay synchronous.
    const resolved = tier1Result || tier2Result || contentTypeMemory.get(titleKey) || null;
    const contentTypePending = !resolved;
    // isSeries is intentionally three-valued: true, false, or null (unknown/
    // pending). It must never default to false just because no evidence was
    // found -- that was the original bug.
    const isSeries = resolved ? resolved.type === "tv_show" : null;

    const scopeLabel = contentTypePending
      ? "title"
      : isSeries
        ? (seasonNumber ? `season ${seasonNumber}` : "series")
        : "movie";
    const sourceLabel = contentTypePending
      ? title
      : isSeries
        ? `${seriesTitle}${seasonNumber ? ` — Season ${seasonNumber}` : ""}`
        : title;
    // While pending, key by title only (not movie:/series:) so the same key
    // is reused once resolved and no decision gets orphaned mid-resolution.
    const sourceKey = contentTypePending
      ? `${site}:content:${stableKeyPart(title)}`
      : isSeries
        ? `${site}:series:${stableKeyPart(seriesTitle)}:season:${seasonNumber || "unknown"}`
        : `${site}:movie:${stableKeyPart(title)}`;
    const normalizedPath = location.pathname.replace(/\/+$/, "") || "/";

    return {
      site,
      contentKey: `${site}:playback:${normalizedPath}`,
      sourceKey,
      title,
      sourceLabel,
      scopeLabel,
      decisionScope: "source",
      isSeries,
      seasonNumber,
      titleKey,
      contentType: resolved?.type || null,
      contentTypeSource: resolved?.source || null,
      contentTypePending
    };
  }

  function getContentInfo() {
    return site === "youtube" ? getYouTubeInfo() : getStreamingInfo();
  }

  function findMainVideo(info = currentInfo) {
    if (!info) return null;

    const videos = [...document.querySelectorAll("video")];
    if (!videos.length) return null;
    return videos
      .map((video) => {
        const rect = video.getBoundingClientRect();
        return { video, area: Math.max(0, rect.width) * Math.max(0, rect.height) };
      })
      .sort((a, b) => b.area - a.area)[0]?.video || null;
  }

  function isVideoPlaying(video) {
    return Boolean(
      video &&
      !video.paused &&
      !video.ended &&
      video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA
    );
  }

  const LANGUAGE_ALIASES = {
    ja: ["japanese", "\u65e5\u672c\u8a9e"],
    en: ["english"], sv: ["swedish", "svenska"], es: ["spanish", "espanol"],
    fr: ["french", "francais"], de: ["german", "deutsch"], it: ["italian", "italiano"],
    pt: ["portuguese", "portugues"], ko: ["korean", "\ud55c\uad6d\uc5b4"],
    zh: ["chinese", "mandarin", "\u4e2d\u6587"], ru: ["russian"], uk: ["ukrainian"],
    ar: ["arabic"], hi: ["hindi"], tr: ["turkish", "turkce"], pl: ["polish", "polski"],
    nl: ["dutch", "nederlands"], da: ["danish", "dansk"], no: ["norwegian", "norsk"],
    fi: ["finnish", "suomi"], vi: ["vietnamese"], th: ["thai"],
    id: ["indonesian", "bahasa indonesia"], ms: ["malay", "bahasa melayu"],
    tl: ["filipino", "tagalog"], el: ["greek"], he: ["hebrew"],
    fa: ["persian", "farsi"], bn: ["bengali", "bangla"], ur: ["urdu"],
    cs: ["czech"], ro: ["romanian"], hu: ["hungarian", "magyar"], bg: ["bulgarian"],
    hr: ["croatian"], sr: ["serbian"], sk: ["slovak"], sl: ["slovenian"],
    et: ["estonian"], lv: ["latvian"], lt: ["lithuanian"], is: ["icelandic"],
    sw: ["swahili", "kiswahili"], ca: ["catalan"], eu: ["basque", "euskara"],
    gl: ["galician"], cy: ["welsh"], ga: ["irish", "gaeilge"]
  };

  const ISO3_CODES = {
    ja: "jpn", en: "eng", sv: "swe", es: "spa", fr: "fra", de: "deu",
    it: "ita", pt: "por", ko: "kor", zh: "zho", ru: "rus", uk: "ukr",
    ar: "ara", hi: "hin", tr: "tur", pl: "pol", nl: "nld", da: "dan",
    no: "nor", fi: "fin", vi: "vie", th: "tha", id: "ind", ms: "msa",
    tl: "tgl", el: "ell", he: "heb", fa: "fas", bn: "ben", ur: "urd",
    cs: "ces", ro: "ron", hu: "hun", bg: "bul", hr: "hrv", sr: "srp"
  };

  const SCRIPT_PATTERNS = {
    ja: /[\u3040-\u30ff]/, ko: /[\uac00-\ud7af]/, zh: /[\u3400-\u9fff]/,
    el: /[\u0370-\u03ff]/, he: /[\u0590-\u05ff]/, hi: /[\u0900-\u097f]/,
    bn: /[\u0980-\u09ff]/, th: /[\u0e00-\u0e7f]/, ka: /[\u10a0-\u10ff]/,
    hy: /[\u0530-\u058f]/, am: /[\u1200-\u137f]/, km: /[\u1780-\u17ff]/,
    lo: /[\u0e80-\u0eff]/, my: /[\u1000-\u109f]/
  };

  function normalizeLanguageCode(value) {
    return String(value || "").trim().toLowerCase().replace(/_/g, "-");
  }

  function baseTargetCode() {
    return normalizeLanguageCode(targetLanguage.code).split("-")[0];
  }

  function isTargetLanguageCode(value) {
    const code = normalizeLanguageCode(value);
    if (!code) return false;
    const targetCode = normalizeLanguageCode(targetLanguage.code);
    const base = baseTargetCode();
    return code === targetCode || code.startsWith(targetCode + "-") ||
      code === base || code.startsWith(base + "-") || code === ISO3_CODES[base];
  }

  function isLanguageCode(value) {
    return /^[a-z]{2,3}(?:-[a-z0-9]{2,8})*$/.test(normalizeLanguageCode(value));
  }

  function normalizeLabelText(value) {
    return String(value || "").toLocaleLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "");
  }

  function languageLabelMatches(value) {
    const text = normalizeLabelText(value);
    if (!text) return false;
    const aliases = [targetLanguage.name, ...(LANGUAGE_ALIASES[baseTargetCode()] || [])]
      .map(normalizeLabelText).filter(Boolean);
    if (aliases.some((alias) => text.includes(alias))) return true;
    const code = baseTargetCode();
    return new RegExp("(^|[\\s(\\[/_-])" + code + "($|[\\s)\\]/_-])", "i").test(text);
  }

  function selectedAudioLabels() {
    const selected = [...document.querySelectorAll(
      '[aria-checked="true"], [aria-selected="true"], [data-uia*="audio-item-selected"], ' +
      '[data-testid*="audio"][data-selected="true"], [data-testid*="audio"][data-state="selected"], ' +
      '[data-uia*="audio-item"][data-selected="true"], [data-uia*="audio-item"].selected, ' +
      '[data-uia*="audio-item"][class*="selected" i], [data-uia*="audio-item"] input:checked'
    )];
    const labels = [];
    for (const element of selected) {
      const item = element.closest?.(
        '[data-uia*="audio-item"], [data-testid*="audio"], [role="menuitemradio"]'
      ) || element;
      const label = item.textContent?.trim() || item.getAttribute("aria-label") ||
        element.textContent?.trim() || element.getAttribute("aria-label") || "";
      if (!label) continue;
      const dataUia = item.getAttribute("data-uia") ||
        item.closest?.("[data-uia]")?.getAttribute("data-uia") || "";
      const dataTestId = item.getAttribute("data-testid") ||
        item.closest?.("[data-testid]")?.getAttribute("data-testid") || "";
      const className = typeof item.className === "string" ? item.className : "";
      const descriptor = `${dataUia} ${dataTestId} ${className} ${item.getAttribute("aria-label") || ""}`;
      if (/subtitle|caption|closed.?caption|text.?track/i.test(descriptor)) continue;
      const isAudio = /audio|sound|dub|voice/i.test(descriptor) ||
        Boolean(item.closest?.(
          '[data-uia*="audio"], [data-testid*="audio"], [class*="audio" i], ' +
          '[aria-label*="Audio"], [aria-label*="audio"]'
        ));
      if (isAudio) labels.push(label);
    }

    const audioTracks = currentVideo?.audioTracks;
    if (audioTracks) {
      for (let index = 0; index < audioTracks.length; index += 1) {
        const track = audioTracks[index];
        if (!track?.enabled) continue;
        const label = compactText(`${track.label || ""} ${track.language || ""}`);
        if (label) labels.push(label);
      }
    }
    return [...new Set(labels)];
  }

  function findSelectedTargetAudioLabel() {
    return selectedAudioLabels().find(languageLabelMatches) || "";
  }

  function looksLikeKnownLanguageLabel(value) {
    const text = normalizeLabelText(value);
    if (!text) return false;
    if (languageLabelMatches(text)) return true;
    if (Object.values(LANGUAGE_ALIASES).flat().some((alias) => text.includes(normalizeLabelText(alias)))) return true;
    return /(?:^|[\s([/_-])[a-z]{2,3}(?:-[a-z]{2,8})?(?:$|[\s)\]/_-])/i.test(text);
  }

  function findSelectedOtherAudioLabel() {
    return selectedAudioLabels().find(
      (label) => !languageLabelMatches(label) && looksLikeKnownLanguageLabel(label)
    ) || "";
  }

  function isAutomaticCaptionTrack(track) {
    const name = String(track?.name || "");
    const kind = String(track?.kind || "").toLowerCase();
    const vssId = String(track?.vssId || "").toLowerCase();
    return kind === "asr" || vssId.includes(".asr") ||
      /auto-generated|automatically generated|automatic captions/i.test(name);
  }

  function findTargetCaptionHint() {
    const probeCaption = (pageProbe.captions || []).some(
      (track) => isTargetLanguageCode(track.languageCode) || languageLabelMatches(track.name)
    );
    if (probeCaption) return true;
    return [...document.querySelectorAll('[aria-checked="true"], [aria-selected="true"]')]
      .some((element) => {
        const dataUia = element.getAttribute("data-uia") ||
          element.closest("[data-uia]")?.getAttribute("data-uia") || "";
        if (!/subtitle|caption/i.test(dataUia)) return false;
        const label = element.textContent?.trim() || element.getAttribute("aria-label") || "";
        return languageLabelMatches(label);
      });
  }

  function findTargetAutoGeneratedCaption() {
    return (pageProbe.captions || []).find((track) =>
      isAutomaticCaptionTrack(track) &&
      (isTargetLanguageCode(track.languageCode) || languageLabelMatches(track.name))
    );
  }

  function findTargetAudioTrackFromProbe() {
    return (pageProbe.audioTracks || []).find((track) => {
      const label = (track.displayName || "") + " " + (track.languageCode || "");
      return (isTargetLanguageCode(track.languageCode) || languageLabelMatches(label)) &&
        (track.audioIsDefault || (pageProbe.audioTracks || []).length === 1);
    });
  }

  function findPrimaryOtherLanguageEvidence() {
    const selectedAudio = findSelectedOtherAudioLabel();
    if (selectedAudio) {
      return "The selected audio track is " + selectedAudio + ", not " + targetLanguage.name + ".";
    }
    if (isStreamingSite) return "";
    const audioTracks = pageProbe.audioTracks || [];
    const primaryTrack = audioTracks.find((track) =>
      (track.audioIsDefault || audioTracks.length === 1) &&
      isLanguageCode(track.languageCode) && !isTargetLanguageCode(track.languageCode)
    );
    if (primaryTrack) {
      return "YouTube reports " + (primaryTrack.displayName || primaryTrack.languageCode) +
        " as the primary audio language.";
    }
    const audioHint = (pageProbe.hints || []).find((hint) => {
      const path = String(hint.path || "").toLowerCase();
      return (path.includes("audio") || path.includes("defaultaudiolanguage")) &&
        isLanguageCode(hint.value) && !isTargetLanguageCode(hint.value);
    });
    if (audioHint) return "YouTube reports another language as the primary audio language.";
    const otherAutomaticCaption = (pageProbe.captions || []).find((track) =>
      isAutomaticCaptionTrack(track) && isLanguageCode(track.languageCode) &&
      !isTargetLanguageCode(track.languageCode)
    );
    return otherAutomaticCaption
      ? "YouTube's automatic captions identify another spoken language."
      : "";
  }

  function targetScriptPattern() {
    return SCRIPT_PATTERNS[baseTargetCode()] || null;
  }

  function looksPredominantlyTargetScript(value) {
    const pattern = targetScriptPattern();
    if (!pattern) return false;
    const text = String(value || "").trim();
    const matches = text.match(new RegExp(pattern.source, "gu")) || [];
    const latin = text.match(/[A-Za-z\u00c0-\u024f]/g) || [];
    return matches.length >= 2 && matches.length >= latin.length * 0.5;
  }

  function findTargetCommentSignal() {
    if (site !== "youtube" || !targetScriptPattern()) return false;
    const comments = [...document.querySelectorAll(
      "ytd-comment-thread-renderer #content-text, ytd-comment-view-model #content-text, ytd-comment-renderer #content-text"
    )].map((element) => element.textContent?.trim() || "").filter(Boolean).slice(0, 12);
    return comments.length >= 3 && comments.every(looksPredominantlyTargetScript);
  }

  function detectTargetLanguage(info) {
    const languageName = targetLanguage.name;
    const selectedAudio = findSelectedTargetAudioLabel();
    if (selectedAudio) return {
      confidence: "high",
      reason: "Selected audio appears to be " + selectedAudio + "."
    };

    if (site === "youtube") {
      const expectedVideoId = String(info.contentKey || "").replace(/^youtube:/, "");
      if (pageProbe.videoId !== expectedVideoId) return {
        confidence: "no-evidence",
        reason: "Waiting for YouTube to expose the current video's language information."
      };

      const probeAudioTrack = findTargetAudioTrackFromProbe();
      if (probeAudioTrack) return {
        confidence: "high",
        reason: "YouTube reports the audio track as " +
          (probeAudioTrack.displayName || languageName) + "."
      };

      const strongHint = (pageProbe.hints || []).find((hint) => {
        const path = String(hint.path || "").toLowerCase();
        return isTargetLanguageCode(hint.value) &&
          (path.includes("audio") || path.includes("defaultaudiolanguage"));
      });
      if (strongHint) return {
        confidence: "high",
        reason: "YouTube reports " + languageName + " as the audio language."
      };

      if (findTargetAutoGeneratedCaption()) return {
        confidence: "high",
        reason: "YouTube generated " + languageName + " captions from the spoken audio."
      };
    }

    const primaryOtherLanguage = findPrimaryOtherLanguageEvidence();
    if (primaryOtherLanguage) return { confidence: "not-target", reason: primaryOtherLanguage };

    if (isStreamingSite) {
      const netflixHelp = site === "netflix"
        ? "Open Netflix's Audio & Subtitles menu once so the selected audio option is present on the page. "
        : "";
      return {
        confidence: "uncertain",
        reason: `${streamingSite.name} did not expose a reliable selected audio language. ` +
          `${netflixHelp}Your choice will be remembered for this ${info.scopeLabel || "title"}.`
      };
    }

    const script = targetScriptPattern();
    const titleMatches = Boolean(script?.test(info.title || ""));
    const sourceMatches = Boolean(script?.test(info.sourceLabel || ""));
    const targetCaptions = findTargetCaptionHint();
    const targetComments = findTargetCommentSignal();
    if (titleMatches || sourceMatches || targetCaptions || targetComments) {
      const evidence = [
        titleMatches ? "title" : "", sourceMatches ? "channel or source" : "",
        targetCaptions ? "captions" : "", targetComments ? "comments" : ""
      ].filter(Boolean).join(", ");
      return {
        confidence: "uncertain",
        reason: languageName + " was found in the " + evidence +
          ", but the primary audio language could not be confirmed."
      };
    }
    return {
      confidence: "no-evidence",
      reason: "No " + languageName + " audio, title, caption, source, or comment signal was found."
    };
  }

  function applyDetectionResult(detection) {
    detectionReason = detection.reason;
    cancelAutoMinimize();

    if (detection.confidence === "high") {
      languageState = "confirmed";
      showExpandedOverlay();
    } else if (detection.confidence === "uncertain") {
      languageState = "awaiting";
      overlayCompact = false;
      renderOverlay();
    } else {
      languageState = detection.confidence === "not-target" ? "primary-other" : "not-candidate";
      if (!overlayManuallyShown) overlay.host.style.display = "none";
      renderOverlay();
    }
    resetSampling(currentVideo);
  }

  async function resolveLanguage(info) {
    if (!isVideoPlaying(currentVideo)) return;

    languageState = "checking";
    statusPausedByUser = false;
    sourceSuggestion = false;
    renderOverlay();

    const automaticDetection = detectTargetLanguage(info);
    if (
      isStreamingSite &&
      ["high", "not-target"].includes(automaticDetection.confidence)
    ) {
      if (pendingLanguageStepKey === info.titleKey) pendingLanguageStepKey = "";
      applyDetectionResult(automaticDetection);
      return;
    }

    const response = await sendMessage({
      type: "getDecision",
      contentKey: info.contentKey,
      sourceKey: info.sourceKey,
      languageCode: targetLanguage.code
    });

    if (!currentInfo || currentInfo.contentKey !== info.contentKey) return;

    if (response?.decision === "target") {
      if (pendingLanguageStepKey === info.titleKey) pendingLanguageStepKey = "";
      languageState = "confirmed";
      detectionReason = isStreamingSite
        ? `Remembered as ${targetLanguage.name} for this ${info.scopeLabel || "title"}; ` +
          `${streamingSite.name} is not currently exposing the selected audio track.`
        : "Remembered as " + targetLanguage.name + ".";
      showExpandedOverlay();
      renderOverlay();
      return;
    }

    if (response?.decision === "not-target") {
      if (pendingLanguageStepKey === info.titleKey) pendingLanguageStepKey = "";
      languageState = "rejected";
      detectionReason = "Remembered as not " + targetLanguage.name + ".";
      overlay.host.style.display = "none";
      renderOverlay();
      return;
    }

    applyDetectionResult(automaticDetection);
  }

  async function monitorStreamingAudioLanguage() {
    if (!isStreamingSite || !currentInfo || !isVideoPlaying(currentVideo)) return;
    const labels = selectedAudioLabels().map(compactText).filter(Boolean).sort();
    if (!labels.length) return;
    const signature = labels.join("|").toLocaleLowerCase();
    if (signature === lastStreamingAudioSignature) return;
    lastStreamingAudioSignature = signature;

    const detection = detectTargetLanguage(currentInfo);
    if (!["high", "not-target"].includes(detection.confidence)) return;
    if (
      (detection.confidence === "high" && languageState === "confirmed") ||
      (detection.confidence === "not-target" && languageState === "primary-other")
    ) return;

    await flushTicks();
    applyDetectionResult(detection);
  }

  function isYouTubeAdPlaying() {
    return site === "youtube" && Boolean(document.querySelector(".html5-video-player.ad-showing"));
  }

  function hasAudibleSound(video) {
    return !browserTabMuted && !video.muted && video.volume > 0;
  }

  function isActiveImmersion() {
    // The background service worker checks the actual selected video tab and
    // whether its Chrome window is focused. The extension popup itself does
    // not make the session passive.
    return browserContextActive;
  }

  function resetSampling(video) {
    lastSampleWall = performance.now();
    lastMediaTime = Number(video?.currentTime) || 0;
  }

  function playbackStateAllowsCounting(video) {
    return Boolean(
      video &&
      !video.paused &&
      !video.ended &&
      !video.seeking &&
      video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA &&
      hasAudibleSound(video) &&
      !isYouTubeAdPlaying() &&
      languageState === "confirmed" &&
      !statusPausedByUser
    );
  }

  function samplePlayback() {
    const video = currentVideo;
    if (!video) return;

    const now = performance.now();
    const mediaTime = Number(video.currentTime) || 0;

    if (!lastSampleWall) {
      resetSampling(video);
      return;
    }

    const wallDelta = Math.max(0, (now - lastSampleWall) / 1000);
    const mediaDelta = mediaTime - lastMediaTime;
    lastSampleWall = now;
    lastMediaTime = mediaTime;

    if (!playbackStateAllowsCounting(video)) return;
    if (wallDelta <= 0 || wallDelta > 180 || mediaDelta <= 0) return;

    const playbackRate = Number(video.playbackRate) || 1;
    const expectedMediaDelta = wallDelta * playbackRate;
    const allowedDifference = Math.max(1.5, expectedMediaDelta * 0.35);

    // A large mismatch is normally a seek/skip. Rewinding itself is not counted,
    // but playback after the rewind is counted again.
    if (Math.abs(mediaDelta - expectedMediaDelta) > allowedDifference) return;

    if (isActiveImmersion()) {
      pendingActive += wallDelta;
      sessionActive += wallDelta;
    } else {
      pendingPassive += wallDelta;
      sessionPassive += wallDelta;
    }

    if (now - lastFlushAt >= 4000 || pendingActive + pendingPassive >= 5) {
      flushTicks();
    }
    renderOverlay();
  }

  async function flushTicks() {
    if (!sessionId || (!pendingActive && !pendingPassive)) return;
    const activeSeconds = pendingActive;
    const passiveSeconds = pendingPassive;
    pendingActive = 0;
    pendingPassive = 0;
    lastFlushAt = performance.now();

    const response = await sendMessage({
      type: "addTick",
      sessionId,
      site,
      contentKey: currentInfo?.contentKey || "",
      title: currentInfo?.title || "Untitled video",
      languageCode: targetLanguage.code,
      activeSeconds,
      passiveSeconds,
      timestamp: Date.now()
    });

    if (response?.ignored) {
      sessionActive = Math.max(0, sessionActive - activeSeconds);
      sessionPassive = Math.max(0, sessionPassive - passiveSeconds);
      renderOverlay();
    }
  }

  async function confirmTargetLanguage(scope = "") {
    if (!currentInfo) return;
    const effectiveScope = scope || currentInfo.decisionScope || "content";
    languageState = "confirmed";
    detectionReason = effectiveScope === "source"
      ? `You confirmed this ${currentInfo.scopeLabel || "source"} as ${targetLanguage.name}.`
      : "You confirmed this video as " + targetLanguage.name + ".";
    const response = await sendMessage({
      type: "saveDecision",
      scope: effectiveScope,
      decision: "target",
      languageCode: targetLanguage.code,
      contentKey: currentInfo.contentKey,
      sourceKey: currentInfo.sourceKey,
      sourceLabel: currentInfo.sourceLabel
    });
    sourceSuggestion = effectiveScope === "content" && Boolean(response?.suggestSource);
    showExpandedOverlay();
    resetSampling(currentVideo);
    renderOverlay();
  }

  async function rejectTargetLanguage({ rollback = true, scope = "" } = {}) {
    if (!currentInfo) return;
    const effectiveScope = scope || currentInfo.decisionScope || "content";
    await flushTicks();
    languageState = "rejected";
    statusPausedByUser = false;

    if (rollback && sessionId) {
      await sendMessage({ type: "rollbackSession", sessionId });
      sessionActive = 0;
      sessionPassive = 0;
    }

    await sendMessage({
      type: "saveDecision",
      scope: effectiveScope,
      decision: "not-target",
      languageCode: targetLanguage.code,
      contentKey: currentInfo.contentKey,
      sourceKey: currentInfo.sourceKey
    });
    sourceSuggestion = false;
    detectionReason = "Marked as not " + targetLanguage.name + ". This session's time was removed.";
    overlay.host.style.display = "none";
    renderOverlay();
  }

  function togglePause() {
    statusPausedByUser = !statusPausedByUser;
    resetSampling(currentVideo);
    renderOverlay();
  }

  function bindVideo(video) {
    if (currentVideo === video) return;
    if (currentVideo) {
      currentVideo.removeEventListener("timeupdate", samplePlayback);
      currentVideo.removeEventListener("playing", onPlaybackBoundary);
      currentVideo.removeEventListener("pause", onPlaybackBoundary);
      currentVideo.removeEventListener("seeking", onPlaybackBoundary);
      currentVideo.removeEventListener("seeked", onPlaybackBoundary);
      currentVideo.removeEventListener("waiting", onPlaybackBoundary);
      currentVideo.removeEventListener("ratechange", onPlaybackBoundary);
    }

    currentVideo = video;
    if (!video) return;
    video.addEventListener("timeupdate", samplePlayback, { passive: true });
    video.addEventListener("playing", onPlaybackBoundary, { passive: true });
    video.addEventListener("pause", onPlaybackBoundary, { passive: true });
    video.addEventListener("seeking", onPlaybackBoundary, { passive: true });
    video.addEventListener("seeked", onPlaybackBoundary, { passive: true });
    video.addEventListener("waiting", onPlaybackBoundary, { passive: true });
    video.addEventListener("ratechange", onPlaybackBoundary, { passive: true });
    resetSampling(video);
  }

  function onPlaybackBoundary() {
    resetSampling(currentVideo);
    renderOverlay();
  }

  async function refreshContext() {
    injectYouTubeProbe();

    const info = getContentInfo();
    const video = findMainVideo(info);
    bindVideo(video);

    const titleChanged =
      currentInfo?.contentKey !== info?.contentKey ||
      currentInfo?.titleKey !== info?.titleKey ||
      currentUrl !== location.href;
    const changed =
      titleChanged ||
      currentInfo?.sourceKey !== info?.sourceKey ||
      currentInfo?.contentType !== info?.contentType;

    currentUrl = location.href;
    if (changed) {
      if (titleChanged) {
        cancelContentTypePrompt();
        pendingLanguageStepKey = "";
      }
      await flushTicks();
      currentInfo = info;
      sessionId = info ? randomId() : null;
      sessionActive = 0;
      sessionPassive = 0;
      pendingActive = 0;
      pendingPassive = 0;
      languageState = info ? "idle" : "unavailable";
      detectionReason = "";
      lastStreamingAudioSignature = "";
      sourceSuggestion = false;
      statusPausedByUser = false;
      overlayCompact = false;
      overlayManuallyShown = false;
      cancelAutoMinimize();
      overlay.host.style.display = "none";
      resetSampling(currentVideo);
      renderOverlay();
    }

    // Movie vs. tv_show must be settled before language decisions are keyed,
    // since sourceKey depends on it. Tier 1/2 already ran synchronously
    // inside getContentInfo(); this only fires when both came back empty and
    // Tier 3 (cached answer or a fresh prompt) is needed.
    if (currentInfo?.contentTypePending) {
      await ensureContentType(currentInfo.titleKey, currentInfo.title);
      return; // Re-run on the next poll tick now that a resolution exists.
    }

    // A supported URL alone is not enough. Language detection and its prompt
    // begin only after the page has a real media element that is playing.
    if (currentInfo && languageState === "idle" && isVideoPlaying(currentVideo)) {
      await resolveLanguage(currentInfo);
    } else if (
      currentInfo &&
      ["not-candidate", "awaiting"].includes(languageState) &&
      isVideoPlaying(currentVideo)
    ) {
      applyDetectionResult(detectTargetLanguage(currentInfo));
    }

    await monitorStreamingAudioLanguage();
  }

  function formatDuration(seconds) {
    const total = Math.max(0, Math.round(seconds));
    const hours = Math.floor(total / 3600);
    const minutes = Math.floor((total % 3600) / 60);
    const secs = total % 60;
    if (hours) return `${hours}h ${String(minutes).padStart(2, "0")}m`;
    return `${minutes}:${String(secs).padStart(2, "0")}`;
  }

  function createOverlay() {
    const host = document.createElement("div");
    host.id = "jit-overlay-host";
    const shadow = host.attachShadow({ mode: "open" });
    shadow.innerHTML = `
      <style>
        .card {
          width: 310px;
          box-sizing: border-box;
          border: 1px solid rgba(148, 163, 184, 0.28);
          border-radius: 14px;
          background: rgba(15, 23, 42, 0.96);
          color: #f8fafc;
          box-shadow: 0 18px 45px rgba(0, 0, 0, 0.35);
          padding: 14px;
          font: 13px/1.4 Inter, ui-sans-serif, system-ui, sans-serif;
          backdrop-filter: blur(12px);
        }
        .card.compact {
          width: auto;
          padding: 0;
          border: 0;
          background: transparent;
          box-shadow: none;
          backdrop-filter: none;
        }
        .row { display: flex; align-items: center; gap: 9px; }
        .between { justify-content: space-between; }
        .dot { width: 9px; height: 9px; border-radius: 999px; flex: 0 0 auto; }
        .active { background: #22c55e; box-shadow: 0 0 0 4px rgba(34, 197, 94, 0.12); }
        .passive { background: #f59e0b; box-shadow: 0 0 0 4px rgba(245, 158, 11, 0.12); }
        .waiting { background: #f59e0b; box-shadow: 0 0 0 4px rgba(245, 158, 11, 0.12); }
        .stopped { background: #94a3b8; }
        .title { font-weight: 750; letter-spacing: -0.01em; }
        .muted { color: #94a3b8; }
        .reason { margin-top: 8px; color: #cbd5e1; font-size: 12px; }
        .stats { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top: 10px; }
        .stat { background: rgba(30, 41, 59, 0.85); padding: 8px 9px; border-radius: 9px; }
        .stat-label { color: #94a3b8; font-size: 11px; }
        .stat-value { margin-top: 2px; font-weight: 700; }
        .buttons { display: flex; flex-wrap: wrap; gap: 7px; margin-top: 11px; }
        button {
          border: 0;
          border-radius: 9px;
          padding: 7px 10px;
          background: #334155;
          color: #f8fafc;
          font: inherit;
          font-weight: 650;
          cursor: pointer;
        }
        button:hover { background: #475569; }
        button.primary { background: #2563eb; }
        button.primary:hover { background: #1d4ed8; }
        button.danger { background: rgba(220, 38, 38, 0.2); color: #fecaca; }
        button.danger:hover { background: rgba(220, 38, 38, 0.32); }
        button.link { background: transparent; padding: 3px 5px; color: #94a3b8; }
        .compact-button {
          display: flex;
          align-items: center;
          gap: 9px;
          padding: 9px 12px;
          border-radius: 999px;
          background: rgba(15, 23, 42, 0.96);
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
          min-width: 118px;
          justify-content: center;
        }
        .drag-handle { cursor: move; user-select: none; touch-action: none; }
        .compact-button strong { font-variant-numeric: tabular-nums; font-size: 14px; }
        .compact-button span:last-child { color: #cbd5e1; font-size: 10px; text-transform: uppercase; }
        .fab-grip { cursor: move; user-select: none; touch-action: none; }
        :host([data-theme="light"]) .card {
          border-color: rgba(100, 116, 139, 0.34);
          background: rgba(255, 255, 255, 0.97);
          color: #172033;
          box-shadow: 0 18px 45px rgba(30, 41, 59, 0.22);
        }
        :host([data-theme="light"]) .card.compact { background: transparent; }
        :host([data-theme="light"]) .reason { color: #46566c; }
        :host([data-theme="light"]) .muted,
        :host([data-theme="light"]) .stat-label { color: #65758b; }
        :host([data-theme="light"]) .stat { background: #edf2f7; }
        :host([data-theme="light"]) button { background: #e2e8f0; color: #172033; }
        :host([data-theme="light"]) button:hover { background: #cfd9e6; }
        :host([data-theme="light"]) button.primary { background: #2563eb; color: #fff; }
        :host([data-theme="light"]) button.primary:hover { background: #1d4ed8; }
        :host([data-theme="light"]) button.danger { background: #feecef; color: #b4233d; }
        :host([data-theme="light"]) button.link { background: transparent; color: #5d6d82; }
        :host([data-theme="light"]) .compact-button {
          background: rgba(255, 255, 255, 0.97);
          color: #172033;
          box-shadow: 0 10px 30px rgba(30, 41, 59, 0.2);
        }
        :host([data-theme="light"]) .compact-button span:last-child { color: #56667a; }
      </style>
      <div class="card" id="card"></div>
    `;
    document.documentElement.appendChild(host);
    host.style.display = "none";
    return { host, shadow, card: shadow.getElementById("card") };
  }

  function setOverlayPosition(left, top, { save = false } = {}) {
    const rect = overlay.host.getBoundingClientRect();
    const width = rect.width || overlay.card.offsetWidth || 120;
    const height = rect.height || overlay.card.offsetHeight || 44;
    const safeLeft = Math.min(Math.max(0, Number(left) || 0), Math.max(0, window.innerWidth - width));
    const safeTop = Math.min(Math.max(0, Number(top) || 0), Math.max(0, window.innerHeight - height));
    overlay.host.style.left = safeLeft + "px";
    overlay.host.style.top = safeTop + "px";
    overlay.host.style.right = "auto";
    if (save) sendMessage({
      type: "setOverlayPosition",
      position: {
        custom: true,
        left: safeLeft,
        top: safeTop,
        viewportWidth: window.innerWidth,
        viewportHeight: window.innerHeight
      }
    });
  }

  function resetOverlayPosition() {
    overlay.host.style.left = "auto";
    overlay.host.style.top = "16px";
    overlay.host.style.right = "18px";
  }

  function clampCurrentOverlayPosition() {
    if (!overlay.host.style.left) return;
    const rect = overlay.host.getBoundingClientRect();
    setOverlayPosition(rect.left, rect.top);
  }

  function initializeOverlayDragging() {
    overlay.shadow.addEventListener("pointerdown", (event) => {
      if (event.button !== 0) return;
      const target = event.target instanceof Element ? event.target : null;
      const handle = target?.closest(".drag-handle");
      if (!handle) return;
      const action = target.closest("[data-action]");
      if (action && !handle.classList.contains("compact-button")) return;

      const rect = overlay.host.getBoundingClientRect();
      overlayDragState = {
        pointerId: event.pointerId,
        handle,
        startX: event.clientX,
        startY: event.clientY,
        left: rect.left,
        top: rect.top,
        moved: false
      };
      try {
        handle.setPointerCapture(event.pointerId);
      } catch {
        // Pointer capture is optional; movement inside the overlay still works.
      }
    });

    overlay.shadow.addEventListener("pointermove", (event) => {
      if (!overlayDragState || event.pointerId !== overlayDragState.pointerId) return;
      const dx = event.clientX - overlayDragState.startX;
      const dy = event.clientY - overlayDragState.startY;
      if (Math.abs(dx) + Math.abs(dy) > 3) overlayDragState.moved = true;
      if (!overlayDragState.moved) return;
      event.preventDefault();
      setOverlayPosition(overlayDragState.left + dx, overlayDragState.top + dy);
    });

    const finishDrag = (event) => {
      if (!overlayDragState || event.pointerId !== overlayDragState.pointerId) return;
      const moved = overlayDragState.moved;
      const rect = overlay.host.getBoundingClientRect();
      overlayDragState = null;
      if (moved) {
        suppressOverlayClick = true;
        setOverlayPosition(rect.left, rect.top, { save: true });
        setTimeout(() => {
          suppressOverlayClick = false;
        }, 0);
        renderOverlay();
      }
    };
    overlay.shadow.addEventListener("pointerup", finishDrag);
    overlay.shadow.addEventListener("pointercancel", finishDrag);
    window.addEventListener("resize", clampCurrentOverlayPosition);
  }

  function cancelAutoMinimize() {
    if (autoMinimizeTimer) {
      clearTimeout(autoMinimizeTimer);
      autoMinimizeTimer = null;
    }
  }

  function scheduleAutoMinimize() {
    cancelAutoMinimize();
    if (
      !overlayPreferences.autoMinimizeEnabled ||
      overlayCompact ||
      languageState !== "confirmed" ||
      overlay.host.style.display === "none"
    ) return;

    const delay = Math.max(1, Number(overlayPreferences.autoMinimizeSeconds) || 5) * 1000;
    autoMinimizeTimer = setTimeout(minimizeOverlay, delay);
  }

  function minimizeOverlay() {
    if (!currentInfo) return;
    cancelAutoMinimize();
    overlayCompact = true;
    overlay.host.style.display = "block";
    renderOverlay();
    requestAnimationFrame(clampCurrentOverlayPosition);
  }

  function showExpandedOverlay() {
    if (!currentInfo) return;
    overlayCompact = false;
    overlay.host.style.display = "block";
    renderOverlay();
    scheduleAutoMinimize();
    requestAnimationFrame(clampCurrentOverlayPosition);
  }

  function toggleOverlayCompact() {
    if (!currentInfo) return false;
    if (overlay.host.style.display === "none" || overlayCompact) showExpandedOverlay();
    else minimizeOverlay();
    return true;
  }

  function applyOverlayPreferences(preferences) {
    overlayPreferences = {
      autoMinimizeEnabled: preferences?.autoMinimizeEnabled !== false,
      autoMinimizeSeconds: Math.min(300, Math.max(1, Number(preferences?.autoMinimizeSeconds) || 5)),
      theme: preferences?.theme === "light" ? "light" : "dark"
    };
    overlay.host.dataset.theme = overlayPreferences.theme;
    const nextTarget = {
      code: normalizeLanguageCode(preferences?.targetLanguage?.code || "ja") || "ja",
      name: String(preferences?.targetLanguage?.name || "Japanese").trim() || "Japanese"
    };
    const targetChanged = nextTarget.code !== targetLanguage.code ||
      nextTarget.name !== targetLanguage.name;
    targetLanguage = nextTarget;

    if (preferences?.overlayPosition?.custom === true) {
      requestAnimationFrame(() => setOverlayPosition(
        preferences.overlayPosition.left,
        preferences.overlayPosition.top
      ));
    } else {
      resetOverlayPosition();
    }
    if (targetChanged && currentInfo) {
      flushTicks();
      sessionId = randomId();
      sessionActive = 0;
      sessionPassive = 0;
      pendingActive = 0;
      pendingPassive = 0;
      languageState = "idle";
      detectionReason = "";
      lastStreamingAudioSignature = "";
      sourceSuggestion = false;
      overlay.host.style.display = "none";
      resetSampling(currentVideo);
      setTimeout(refreshContext, 0);
    }
    if (!overlayCompact && overlay.host.style.display !== "none") scheduleAutoMinimize();
  }

  async function loadOverlayPreferences() {
    const response = await sendMessage({ type: "getPreferences" });
    if (response?.preferences) applyOverlayPreferences(response.preferences);
  }

  function recordingMode() {
    if (!currentVideo || languageState !== "confirmed" || statusPausedByUser) return "stopped";
    if (!playbackStateAllowsCounting(currentVideo)) return "stopped";
    return isActiveImmersion() ? "active" : "passive";
  }

  function renderOverlay() {
    if (!overlay?.card || overlayDragState) return;

    if (contentTypePrompt) {
      overlay.card.classList.remove("compact");
      overlay.host.style.display = "block";
      overlay.card.innerHTML = `
        <div class="row drag-handle">
          <span class="dot waiting"></span>
          <div class="title">Is "${escapeHtml(contentTypePrompt.titleLabel)}" a TV show or a movie?</div>
        </div>
        <div class="reason"><strong>Step 1 of 2.</strong> This site didn't expose enough season or episode info to tell automatically. Your answer is remembered for this title, so you won't be asked again. Next, we'll confirm the language.</div>
        <div class="buttons">
          <button class="primary" data-action="content-type-tv-show">TV Show</button>
          <button data-action="content-type-movie">Movie</button>
        </div>
      `;
      overlay.card.querySelector('[data-action="content-type-tv-show"]')
        ?.addEventListener("click", () => resolveContentTypePrompt("tv_show"));
      overlay.card.querySelector('[data-action="content-type-movie"]')
        ?.addEventListener("click", () => resolveContentTypePrompt("movie"));
      return;
    }

    if (!currentInfo) {
      overlay.host.style.display = "none";
      return;
    }

    overlay.card.classList.toggle("compact", overlayCompact);

    if (overlayCompact) {
      const mode = recordingMode();
      overlay.card.innerHTML =
        '<button class="compact-button fab-grip drag-handle" data-action="expand-full" ' +
          'title="Drag to move or click to open full status" aria-label="Open full immersion status">' +
          '<span class="dot ' + mode + '"></span>' +
          '<strong>' + escapeHtml(formatDuration(sessionActive + sessionPassive)) + '</strong>' +
          '<span>session</span>' +
        '</button>';

      overlay.card.querySelector('[data-action="expand-full"]')?.addEventListener("click", () => {
        if (!suppressOverlayClick) showExpandedOverlay();
      });
      sendStatus();
      return;
    }

    if (languageState === "awaiting") {
      cancelAutoMinimize();
      overlayCompact = false;
      if (!isVideoPlaying(currentVideo) && !overlayManuallyShown) {
        overlay.host.style.display = "none";
        return;
      }
      overlay.host.style.display = "block";
      const rememberedScope = currentInfo.scopeLabel || "title";
      const confirmationGuidance = isStreamingSite
        ? `Confirm only when the selected spoken audio is ${targetLanguage.name}. Subtitles do not count.`
        : `Count it when roughly 90% or more of the spoken content is ${targetLanguage.name}.`;
      const stepLabel = pendingLanguageStepKey && pendingLanguageStepKey === currentInfo.titleKey
        ? "<strong>Step 2 of 2.</strong> "
        : "";
      if (stepLabel) pendingLanguageStepKey = "";
      overlay.card.innerHTML = `
        <div class="row drag-handle">
          <span class="dot waiting"></span>
          <div class="title">${isStreamingSite ? "Is the selected audio " : "Is this mostly "}${escapeHtml(targetLanguage.name)}?</div>
        </div>
        <div class="reason">${stepLabel}${escapeHtml(detectionReason)} ${escapeHtml(confirmationGuidance)}</div>
        <div class="buttons">
          <button class="primary" data-action="yes">Yes, count this ${escapeHtml(isStreamingSite ? rememberedScope : "video")}</button>
          ${!isStreamingSite && currentInfo.sourceKey ? `<button data-action="always">Always count channel</button>` : ""}
          <button class="danger" data-action="no">No${isStreamingSite ? `, don't count this ${escapeHtml(rememberedScope)}` : ""}</button>
        </div>
      `;
    } else if (languageState === "confirmed") {
      const mode = recordingMode();
      const audible = currentVideo ? hasAudibleSound(currentVideo) : false;
      const playing = currentVideo && !currentVideo.paused && !currentVideo.ended;
      const languageName = targetLanguage.name;
      const label = statusPausedByUser
        ? "Tracking paused"
        : mode === "active"
          ? "Recording active " + languageName
          : mode === "passive"
            ? "Recording passive " + languageName
            : !playing
              ? languageName + " confirmed - video paused"
              : !audible
                ? languageName + " confirmed - sound is off"
                : languageName + " confirmed - waiting for playback";

      overlay.card.innerHTML = `
        <div class="row between drag-handle">
          <div class="row">
            <span class="dot ${mode}"></span>
            <div class="title">${escapeHtml(label)}</div>
          </div>
          <button class="link" data-action="minimize" aria-label="Minimize">&minus;</button>
        </div>
        <div class="reason">${escapeHtml(detectionReason)}</div>
        ${sourceSuggestion ? `<div class="reason"><strong>You have confirmed several videos from ${escapeHtml(currentInfo.sourceLabel)}.</strong> Count future ${escapeHtml(languageName)} videos from this source automatically?</div>` : ""}
        <div class="stats">
          <div class="stat"><div class="stat-label">Active this session</div><div class="stat-value">${formatDuration(sessionActive)}</div></div>
          <div class="stat"><div class="stat-label">Passive this session</div><div class="stat-value">${formatDuration(sessionPassive)}</div></div>
        </div>
        <div class="buttons">
          ${sourceSuggestion ? `<button class="primary" data-action="always-now">Always count ${site === "youtube" ? "this channel" : "this title"}</button><button data-action="dismiss-source">Not yet</button>` : ""}
          <button data-action="pause">${statusPausedByUser ? "Resume tracking" : "Pause tracking"}</button>
          <button data-action="minimize">Minimize</button>
          <button data-action="hide">Hide</button>
          <button class="danger" data-action="wrong">Not ${escapeHtml(languageName)} - remove time</button>
        </div>
      `;
    } else if (["rejected", "not-candidate", "primary-other"].includes(languageState)) {
      const stoppedLabel = languageState === "rejected"
        ? "Not tracking this video"
        : "Automatic detection did not mark this as " + targetLanguage.name;
      overlay.card.innerHTML = `
        <div class="row drag-handle">
          <span class="dot stopped"></span>
          <div class="title">${escapeHtml(stoppedLabel)}</div>
        </div>
        <div class="reason">${escapeHtml(detectionReason)}</div>
        <div class="buttons"><button data-action="change">Actually, count it</button><button class="link" data-action="hide">Hide</button></div>
      `;
    } else if (languageState === "checking") {
      if (!overlayManuallyShown) {
        overlay.host.style.display = "none";
        return;
      }
      overlay.host.style.display = "block";
      overlay.card.innerHTML = `
        <div class="row drag-handle"><span class="dot waiting"></span><div class="title">Checking selected audio...</div></div>
        <div class="reason">Keep the streaming site's audio menu open briefly if it is available.</div>
        <div class="buttons"><button class="link" data-action="hide">Hide</button></div>
      `;
    } else {
      if (!overlayManuallyShown) {
        overlay.host.style.display = "none";
        return;
      }
      overlay.host.style.display = "block";
      overlay.card.innerHTML = `
        <div class="row drag-handle"><span class="dot stopped"></span><div class="title">Waiting for playback</div></div>
        <div class="reason">Start the video to check its spoken audio language.</div>
        <div class="buttons"><button class="link" data-action="hide">Hide</button></div>
      `;
    }

    overlay.card.querySelector('[data-action="yes"]')?.addEventListener("click", () => confirmTargetLanguage());
    overlay.card.querySelector('[data-action="always"]')?.addEventListener("click", () => confirmTargetLanguage("source"));
    overlay.card.querySelector('[data-action="always-now"]')?.addEventListener("click", () => confirmTargetLanguage("source"));
    overlay.card.querySelector('[data-action="dismiss-source"]')?.addEventListener("click", async () => {
      sourceSuggestion = false;
      await sendMessage({
        type: "dismissSourceSuggestion",
        sourceKey: currentInfo?.sourceKey || "",
        languageCode: targetLanguage.code
      });
      renderOverlay();
    });
    overlay.card.querySelector('[data-action="no"]')?.addEventListener("click", () => rejectTargetLanguage({ rollback: false }));
    overlay.card.querySelector('[data-action="wrong"]')?.addEventListener("click", () => rejectTargetLanguage({ rollback: true }));
    overlay.card.querySelector('[data-action="pause"]')?.addEventListener("click", togglePause);
    overlay.card.querySelectorAll('[data-action="minimize"]').forEach((button) => {
      button.addEventListener("click", minimizeOverlay);
    });
    overlay.card.querySelector('[data-action="change"]')?.addEventListener("click", () => confirmTargetLanguage());
    overlay.card.querySelector('[data-action="hide"]')?.addEventListener("click", () => {
      overlayManuallyShown = false;
      cancelAutoMinimize();
      overlay.host.style.display = "none";
    });

    sendStatus();
  }

  function escapeHtml(value) {
    return String(value || "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function sendStatus() {
    const mode = recordingMode();
    const state =
      languageState === "awaiting"
        ? "awaiting"
        : mode === "active"
          ? "recording-active"
          : mode === "passive"
            ? "recording-passive"
            : "stopped";

    sendMessage({
      type: "status",
      status: {
        state,
        languageState,
        targetLanguage: { ...targetLanguage },
        languageCode: targetLanguage.code,
        languageName: targetLanguage.name,
        site,
        title: currentInfo?.title || "",
        contentKey: currentInfo?.contentKey || "",
        sessionId,
        sessionActive,
        sessionPassive,
        detectionReason,
        audible: currentVideo ? hasAudibleSound(currentVideo) : false,
        playing: Boolean(currentVideo && !currentVideo.paused && !currentVideo.ended),
        countingEligible: currentVideo ? playbackStateAllowsCounting(currentVideo) : false,
        trackingPaused: statusPausedByUser,
        pageVisible: document.visibilityState === "visible",
        pageFocused: document.hasFocus()
      }
    }).then((response) => {
      let changed = false;
      if (typeof response?.tabMuted === "boolean" && response.tabMuted !== browserTabMuted) {
        browserTabMuted = response.tabMuted;
        changed = true;
      }
      if (typeof response?.activeImmersion === "boolean" && response.activeImmersion !== browserContextActive) {
        samplePlayback();
        flushTicks();
        browserContextActive = response.activeImmersion;
        changed = true;
      }
      if (changed) resetSampling(currentVideo);
    });
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type === "confirmCurrentLanguage" || message.type === "confirmCurrentJapanese") {
      confirmTargetLanguage().then(() => sendResponse({ ok: true }));
      return true;
    }
    if (message.type === "rejectCurrentLanguage" || message.type === "rejectCurrentJapanese") {
      rejectTargetLanguage({ rollback: true }).then(() => sendResponse({ ok: true }));
      return true;
    }
    if (message.type === "showTrackerOverlay") {
      if (!currentInfo) {
        sendResponse({ ok: false, reason: "no-video" });
        return false;
      }
      overlayManuallyShown = true;
      showExpandedOverlay();
      sendResponse({ ok: true });
      return false;
    }
    if (message.type === "toggleTrackerPause") {
      if (!currentInfo || languageState !== "confirmed") {
        sendResponse({ ok: false, reason: "no-confirmed-video" });
        return false;
      }
      togglePause();
      sendResponse({ ok: true, paused: statusPausedByUser });
      return false;
    }
    if (message.type === "toggleOverlayCompact") {
      sendResponse({ ok: toggleOverlayCompact() });
      return false;
    }
    if (message.type === "overlayPreferencesChanged") {
      applyOverlayPreferences(message.preferences);
      sendResponse({ ok: true });
      return false;
    }
    if (message.type === "browserContextChanged") {
      const nextActive = Boolean(message.activeImmersion);
      if (nextActive !== browserContextActive) {
        samplePlayback();
        flushTicks();
        browserContextActive = nextActive;
        resetSampling(currentVideo);
        renderOverlay();
      }
      sendResponse({ ok: true });
      return false;
    }
    return false;
  });

  document.addEventListener("fullscreenchange", () => {
    const fullscreenParent = document.fullscreenElement;
    if (fullscreenParent && !(fullscreenParent instanceof HTMLVideoElement)) {
      fullscreenParent.appendChild(overlay.host);
    } else if (!fullscreenParent) {
      document.documentElement.appendChild(overlay.host);
    }
    renderOverlay();
    sendStatus();
  });
  document.addEventListener("visibilitychange", () => {
    resetSampling(currentVideo);
    renderOverlay();
    sendStatus();
  });
  window.addEventListener("focus", sendStatus);
  window.addEventListener("blur", sendStatus);
  window.addEventListener("pagehide", () => flushTicks());

  injectYouTubeProbe();
  loadOverlayPreferences();
  watchHeadForContentTypeTags();
  refreshContext();
  setInterval(() => {
    refreshContext();
    samplePlayback();
    if (performance.now() - lastFlushAt >= 5000) flushTicks();
    sendStatus();
  }, 1000);
})();
